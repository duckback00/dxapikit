#!/bin/bash
#
#jet_build.sh						jetstream_container_delete_jq.sh
#jetstream_bookmark_create_from_latest_jq.sh		jetstream_container_refresh_jq.sh
#jetstream_bookmark_create_from_latest_jq.sh_v1110	jetstream_container_reset_jq.sh
#jetstream_bookmark_create_from_timestamp_jq.sh		jetstream_container_restore_to_bookmark_jq.sh
#jetstream_bookmark_delete_jq.sh			jetstream_container_restore_to_timestamp_jq.sh
#jetstream_branch_create_from_bookmark_jq.sh		jetstream_container_stop_start_jq.sh
#jetstream_branch_create_from_latest_jq.sh		jetstream_container_users_jq.sh
#jetstream_branch_create_from_timestamp_jq.sh		jetstream_objects_json.sh
#jetstream_branch_operations_jq.sh			jetstream_template_create_jq.sh
#jetstream_container_active_branch_at_timestamp.sh	jetstream_template_delete_jq.sh
#jetstream_container_create_jq.sh
#

if [[ "${1}" == "delete" ]]
then
   ./jetstream_container_delete_jq.sh tpl dc delete false
   ./jetstream_template_delete_jq.sh tpl delete
elif [[ "${1}" == "restore" ]]
then
   ./jetstream_container_restore_to_bookmark_jq.sh tpl dc baseline
elif [[ "${1}" == "refresh" ]]
then
   ./vdb_operations.sh sync Vdelphix_demo
   ./jetstream_container_refresh_jq.sh tpl dc
elif [[ "${1}" == "create" ]]
then
   ./jetstream_template_create_jq.sh tpl Vdelphix_demo ds
   ./jetstream_container_create_jq.sh tpl ds VVdelphix_demo dc
   ./jetstream_bookmark_create_from_latest_jq.sh tpl dc baseline false "\"tag123\""
else 
   echo "Invalid option, please use ./jet_build_sqlserver.sh  [ create | delete | restore ] "
fi
