#!/bin/bash


which gdate 1> /dev/null 2> /dev/null
if [ $? -eq 0 ]
then
   GDT=gdate
else
   GDT=date
fi
export GDT
echo "Date Command: ${GDT}"


#TZ=$1
echo " "
echo "Timestamp Format \"[yyyy]-[MM]-[dd]T[HH]:[mm]:[ss].[SSS]Z\""
echo "Example: 2016-10-19T02:24:21.000Z"
echo "... or ... enter any valid date string"
echo "Examples:  \"05/08 3:45pm\"    or    \"2:10am\""
echo "Enter Search Timestamp (exclude quotes): "
while read TZ; do
   if [[ "${TZ}" == "" ]]
   then
      echo "No Timestamp provided, exiting ... ${TZ} "
      exit 1
   fi
   echo "Input: ${TZ}" 

   # Not Needed # TZ=$(echo "${TZ}" | tr 'T' ' ' | tr 'Z' ' ')

   let HR=2
   let UTC=-4
   let HB=UTC+${HR}
   let HA=UTC-${HR}
   ${GDT} --date="${TZ}" "+%Y/%m/%d %H:%M:%S"
   if [[ $_ ]] 
   then
      echo "error"
   else 
      echo "okay"
   fi
   DT=`${GDT} --date="${TZ}" "+%Y/%m/%d %H:%M:%S"`

   TZ=`${GDT} --date="${DT} ${UTC}" "+%Y-%m-%dT%H:%M:%S.000Z"`
   TZB=`${GDT} --date="${DT} ${HB}" "+%Y-%m-%dT%H:%M:%S.000Z"` 
   TZA=`${GDT} --date="${DT} ${HA}" "+%Y-%m-%dT%H:%M:%S.000Z"`

   echo "${TZ}"
   echo "${TZB}"
   echo "${TZA}"

done

