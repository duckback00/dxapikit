#!/bin/bash
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2017 by Delphix. All rights reserved.
#
# Program Name : vdb_init.sh
# Description  : Delphix API calls to change the state of VDB's
# Author       : Alan Bitterman
# Created      : 2017-08-09
# Version      : v1.2
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#  3.) Include ./jqJSON_subroutines.sh
#
# Interactive Usage: ./azure_hooks.sh
#
# Non-Interactive Usage: ./azure_hooks.sh [VDB_Name] 
#
#########################################################
#                     DELPHIX CORP                      #
#########################################################

if [[ -d "${APIPATH}" ]]
then
   . ${APIPATH}/jqJSON_subroutines.sh
   . ${APIPATH}/delphix_engine.conf
else

#########################################################
## Subroutines ...

. `pwd`/jqJSON_subroutines.sh

#########################################################
## Parameter Initialization ...

. `pwd`/delphix_engine.conf

fi

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ..."
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get API Version Info ...

APIVAL=$( jqGet_APIVAL )
if [ "${APIVAL}" == "" ]
then
   echo "Error: Delphix Engine API Version Value Unknown ${APIVAL} ..."
#else
#   echo "Delphix Engine API Version: ${APIVAL}"
fi

#########################################################
## Command Line Arguments ...

#########################################################
## Get source container

STATUS=`curl -s -X GET -k ${BaseURL}/source -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "results> $RESULTS"

SOURCE_SID="$1"
if [[ "${SOURCE_SID}" == "" ]]
then

   VDB_NAMES=`echo "${STATUS}" | jq --raw-output '.result[] | .name '`
   echo "---------------------------------"
   echo "VDB Names: [copy-n-paste]"
   echo "${VDB_NAMES}"
   echo " "

   echo "Please Enter dSource or VDB Name (case sensitive): "
   read SOURCE_SID
   if [ "${SOURCE_SID}" == "" ]
   then
      echo "No dSource or VDB Name Provided, Exiting ..."
      exit 1;
   fi
fi;
export SOURCE_SID

#
# Parse out container reference for name of $SOURCE_SID ...
#
CONTAINER_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_SID}"'") | .reference '`
echo "database container reference: ${CONTAINER_REFERENCE}"
if [[ "${CONTAINER_REFERENCE}" == "" ]]
then
   echo "Error: No container found for ${SOURCE_SID} ${CONTAINER_REFERENCE}, Exiting ..."
   exit 1;
fi

#
# Parse out container type ...
#
CONTAINER_TYPE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_SID}"'") | .type '`
echo "database container type: ${CONTAINER_TYPE}"

#########################################################
#

JSON="{
   \"operations\": {
	\"preRefresh\":[{
		\"command\":\"echo \\\"pre_refresh\\\" > ~/.azsql_hook_${SOURCE_SID}\",
		\"name\":\"az_prerefresh\",
		\"type\":\"RunPowerShellOnSourceOperation\"
	}],
        \"preRollback\":[{
		\"command\":\"echo \\\"pre_rollback\\\" > ~/.azsql_hook_${VDB_NAME}\",
		\"name\":\"az_prerollback\",
		\"type\":\"RunPowerShellOnSourceOperation\"
	}],
	\"postSnapshot\":[{
		\"command\":\"rm ~./azsql_hook_${VDB_NAME} 2>/dev/null\",
		\"name\":\"az_postsnapshot\",
		\"type\":\"RunPowerShellOnSourceOperation\"
	}],
	\"type\":\"VirtualSourceOperations\"
   },
   \"type\":\"MSSqlVirtualSource\"
}"

#   \"type\":\"AppDataVirtualSource\"

echo "URI: ${BaseURL}/source/${CONTAINER_REFERENCE}"
echo "JSON: ${JSON}"

STATUS=`curl -s -X POST -k --data @- ${BaseURL}/source/${CONTAINER_REFERENCE} -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${JSON}
EOF
`

echo "${STATUS}" | jq -r "."
#########################################################
## Get Job Number ...

JOB=$( jqParse "${STATUS}" "job" )
echo "Job: ${JOB}"

#jqJobStatus "${JOB}"            # Job Status Function ...

############## E O F ####################################
echo "Done ..."
echo " "
exit 0;

