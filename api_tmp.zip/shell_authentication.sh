#!/bin/bash

#
# Copy-n-Paste Shell Command Line Basic Snipets 
#

########################################################
## Variables ...

# Replace these Variables as required ...

DMIP="172.16.160.195" 
DMURL="http://${DMIP}/resources/json/delphix"
DMUSER="admin"
DMPASS="Admin-12"
echo "Delphix Engine URL: ${DMURL}"
echo "Delphix User: ${DMUSER}" 

########################################################
## Session API ...

echo "Session API "
curl -s -X POST -k --data @- ${DMURL}/session -c "cookies.txt" -H "Content-Type: application/json" <<EOF
{
    "type": "APISession",
    "version": {
        "type": "APIVersion",
        "major": 1,
        "minor": 10,
        "micro": 0
    }
}
EOF


########################################################
## Login API ...

echo " "
echo "Login API "
curl -s -X POST -k --data @- ${DMURL}/login -b "cookies.txt" -c "cookies.txt" -H "Content-Type: application/json" <<EOF
{
  "type": "LoginRequest",
  "username": "${DMUSER}",
  "password": "${DMPASS}"
}
EOF


########################################################
## Get some Delphix Objects ...

echo " " 
#echo "Environment API"
#curl -X GET -k ${DMURL}/environment -b "cookies.txt" -H "Content-Type: application/json"

#echo "Database API"
#curl -X GET -k ${DMURL}/database -b "cookies.txt" -H "Content-Type: application/json"

echo "About API"
curl -X GET -k ${DMURL}/about -b "cookies.txt" -H "Content-Type: application/json"

########################################################
## Capture the return JSON String to a Shell Variable ...

#echo " " 
#echo "Capture curl output, JSON, and parse ..." 
#STATUS=`curl -s -X GET -k ${DMURL}/about -b "cookies.txt" -H "Content-Type: application/json"`

########################################################
## jq examples ...

#echo "${STATUS}" | jq "."
#echo "${STATUS}" | jq ".status"
#echo "${STATUS}" | jq ".result.apiVersion"

########################################################
## The End ...
exit
