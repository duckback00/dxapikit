#!/bin/bash
# 
# Usage: 
#  ./jet_build.sh [ create | delete | restore | refresh ] [bookmarkname] [tags]
#

#DSOURCE="orcl"
#VDB="VBITT"
DSOURCE="AppData"
VDB="VAppData"
GROUP="AppData"
TPL="tpl"
DS="ds"
DC="dc"
BOOKMARK=""
TAGS="\"\""

if [[ "${2}" != "" ]] 
then
   BOOKMARK="${2}"
fi

if [[ "${3}" != "" ]]
then
   TAGS="${3}"
fi

echo "Action: ${1}"
echo "Bookmark: ${BOOKMARK}"
echo "Note: Tags must be enclosed in escaped double quotes ..."
echo "Tags: ${TAGS}"

#
# Logic
#
if [[ "${1}" == "delete" ]]
then
   ./jetstream_container_delete_jq.sh ${TPL} ${DC} delete false
   ./jetstream_template_delete_jq.sh ${TPL} delete
   if [[ "${DSOURCE}" == "AppData" ]]
   then
      ./build_my_datasets.sh appdata delete
      ./group_operations.sh delete "${GROUP}"
   fi
elif [[ "${1}" == "restore" ]] || [[ "${1}" == "rewind" ]] || [[ "${1}" == "rollback" ]]
then
   if [[ "${BOOKMARK}" != "" ]]
   then
      ./jetstream_container_restore_to_bookmark_jq.sh ${TPL} ${DC} "${BOOKMARK}"
   else
      ./jetstream_container_reset_jq.sh ${TPL} ${DC} 
   fi
elif [[ "${1}" == "refresh" ]]
then
   ./jetstream_container_refresh_jq.sh ${TPL} ${DC}
elif [[ "${1}" == "create" ]]
then
   if [[ "${DSOURCE}" == "AppData" ]]
   then
      ./group_operations.sh create "${GROUP}"
      ./build_my_datasets.sh appdata create
   fi
   ./jetstream_template_create_jq.sh ${TPL} ${DSOURCE} ${DS}
   ./jetstream_container_create_jq.sh ${TPL} ${DS} ${VDB} ${DC}
   if [[ "${BOOKMARK}" == "" ]]
   then
      BOOKMARK="baseline"
   fi
   ./jetstream_bookmark_create_from_latest_jq.sh ${TPL} ${DC} "${BOOKMARK}" false "${TAGS}"
elif [[ "${1}" == "createad" ]]
then
   if [[ "${DSOURCE}" == "AppData" ]]
   then
      ./group_operations.sh create "${GROUP}"
      ./build_my_datasets.sh appdata create
   fi
elif [[ "${1}" == "createjet" ]]
then
   ./jetstream_template_create_jq.sh ${TPL} ${DSOURCE} ${DS}
   ./jetstream_container_create_jq.sh ${TPL} ${DS} ${VDB} ${DC}
   if [[ "${BOOKMARK}" == "" ]]
   then
      BOOKMARK="baseline"
   fi
   ./jetstream_bookmark_create_from_latest_jq.sh ${TPL} ${DC} "${BOOKMARK}" false "${TAGS}"
else 
   echo "Invalid option, please use ./jet_build.sh  [ create | delete | restore | refresh ] "
fi

exit
