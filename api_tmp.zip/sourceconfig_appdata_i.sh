#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : sourceconfig_appdata_i.sh
# Description  : Delphix API AppData Add dSource (AppData) 
# Author       : Alan Bitterman
# Created      : 2019-08-12
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: ./sourceconfig_appdata_i.sh
#
# ./sourceconfig_appdata_i.sh [sourceconfig_name] [host] [repository] [mountPath]
# ./sourceconfig_appdata_i.sh AppData "Linux Host" "Unstructured Files" /u01/delphixData/data1
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

DEF_SOURCE_NAME=""
DEF_SOURCE_HOST=""
DEF_SOURCE_REPO=""
DEF_SOURCE_PATH=""

#DEF_SOURCE_NAME="AppData"
#DEF_SOURCE_HOST="Linux Host"
#DEF_SOURCE_REPO="Unstructured Files"
#DEF_SOURCE_PATH="/u01/delphixData/data1"

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq -r "."

# "type": "AppDataDirectSourceConfig",
# "namespace": null,

SOURCE_NAME="${1}"
if [[ "${SOURCE_NAME}" == "" ]]
then
   ZTMP="New Source Name"
   if [[ "${DEF_SOURCE_NAME}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.namespace==null) | .name '`
      echo "---------------------------------"
      echo "Existing ${ZTMP}s: [do not use]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SOURCE_NAME
      if [[ "${SOURCE_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SOURCE_NAME=${DEF_SOURCE_NAME}
   fi
fi

SOURCE_CFG=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_NAME}"'" and .namespace==null) | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

if [[ "${SOURCE_CFG}" != "" ]]
then
   echo "Error: ${SOURCE_NAME} Already Exists, exiting ..."
   exit 1
fi

#########################################################
## Get Environment ...

STATUS=`curl -s -X GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq -r "."

SOURCE_HOST="${2}"
if [[ "${SOURCE_HOST}" == "" ]]
then
   ZTMP="Source Host"
   if [[ "${DEF_SOURCE_HOST}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SOURCE_HOST
      if [[ "${SOURCE_HOST}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SOURCE_HOST=${DEF_SOURCE_HOST}
   fi
fi

ENV_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_HOST}"'" and .namespace==null) | .reference '`
echo "env reference: ${ENV_REFERENCE}"

#########################################################
## Get Repository reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/repository -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

SOURCE_REPO="${3}"
if [[ "${SOURCE_REPO}" == "" ]]
then
   ZTMP="Source Repository"
   if [[ "${DEF_SOURCE_REPO}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SOURCE_REPO
      if [[ "${SOURCE_REPO}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SOURCE_REPO=${DEF_SOURCE_REPO}
   fi
fi

#
# Parse out reference for name of $ENV_REFERENCE ...
#
REP_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .name=="'"${SOURCE_REPO}"'" and .namespace==null) | .reference '`
echo "repository reference: ${REP_REFERENCE}"
if [[ "${REP_REFERENCE}" == "" ]]
then
   echo "Error: No repository reference found for ${SOURCE_HOST} and ${SOURCE_REPO}, please verify values. Exiting ..."
   exit 1;
fi

#########################################################
## Data Path ...

SOURCE_PATH="${4}"
if [[ "${SOURCE_PATH}" == "" ]]
then
   ZTMP="Data Path"
   if [[ "${DEF_SOURCE_PATH}" == "" ]]
   then
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SOURCE_PATH
      if [[ "${SOURCE_PATH}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SOURCE_PATH=${DEF_SOURCE_PATH}
   fi
fi

#########################################################
## SourceConfig API Call ...

json="{
    \"type\": \"AppDataDirectSourceConfig\",
    \"name\": \"${SOURCE_NAME}\",
    \"repository\": \"${REP_REFERENCE}\",
    \"path\": \"${SOURCE_PATH}\"
}"

echo "JSON: ${json}" 

echo "sourceconfig API "
STATUS=`curl -s -X POST -k --data @- $BaseURL/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`

echo ${STATUS} | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

## No Job Number ...

# 
# The End is Here ...
#
echo " "
echo "Done "
exit 0;
