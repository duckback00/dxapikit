#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : sourceconfig_delete_i.sh
# Description  : Delphix API AppData Add dSource (AppData) 
# Author       : Alan Bitterman
# Created      : 2019-08-12
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: ./sourceconfig_delete_i.sh
#
# ./sourceconfig_delete_i.sh [sourceconfig_name] 
# ./sourceconfig_delete_i.sh AppData 
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

DEF_SOURCE_NAME=""

#DEF_SOURCE_NAME="AppData"

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq -r "."

# "type": "AppDataDirectSourceConfig",
# "namespace": null,

SOURCE_NAME="${1}"
if [[ "${SOURCE_NAME}" == "" ]]
then
   ZTMP="New Source Name"
   if [[ "${DEF_SOURCE_NAME}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.namespace==null) | .name '`
      echo "---------------------------------"
      echo "Existing ${ZTMP}s: [do not use]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SOURCE_NAME
      if [[ "${SOURCE_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SOURCE_NAME=${DEF_SOURCE_NAME}
   fi
fi

SOURCE_CFG=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_NAME}"'" and .namespace==null) | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

if [[ "${SOURCE_CFG}" == "" ]]
then
   echo "Error: ${SOURCE_NAME} Does NOT Exist, exiting ..."
   exit 1
fi

#########################################################
## SourceConfig API Call ...

echo "JSON: ${json}" 

echo "sourceconfig API "
STATUS=`curl -s -X DELETE $BaseURL/sourceconfig/${SOURCE_CFG} -b "${COOKIE}" -H "${CONTENT_TYPE}"`

echo ${STATUS} | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

## No Job Number ...

# 
# The End is Here ...
#
echo " "
echo "Done "
exit 0;
