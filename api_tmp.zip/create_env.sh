#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2020 by Delphix. All rights reserved.
#
# Program Name : create_centos_env.sh
# Description  : Delphix API create environment 
# Author       : Alan Bitterman
# Created      : 2020-02-02
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: 
# ./create_centos_env.sh
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."


#########################################################
## Create Environment ...

#
# Windows ...
# 
json="{
    \"type\": \"HostEnvironmentCreateParameters\",
    \"primaryUser\": {
        \"type\": \"EnvironmentUser\",
        \"name\": \".\\\Administrator\",
        \"credential\": {
            \"type\": \"PasswordCredential\",
            \"password\": \"Bitterman00!\"
        }
    },
    \"hostEnvironment\": {
        \"type\": \"WindowsHostEnvironment\",
        \"name\": \"Windows Host\"
    },
    \"hostParameters\": {
        \"type\": \"WindowsHostCreateParameters\",
        \"host\": {
            \"type\": \"WindowsHost\",
            \"address\": \"172.16.160.134\",
            \"connectorPort\": 9100
        }
    }
}"

#
# Unix/Linux ...
#
json="{
    \"type\": \"HostEnvironmentCreateParameters\",
    \"primaryUser\": {
        \"type\": \"EnvironmentUser\",
        \"name\": \"postgres\",
        \"credential\": {
            \"type\": \"PasswordCredential\",
            \"password\": \"delphix\"
        }
    },
    \"hostEnvironment\": {
        \"type\": \"UnixHostEnvironment\",
        \"name\": \"awsCentos\"
    },
    \"hostParameters\": {
        \"type\": \"UnixHostCreateParameters\",
        \"host\": {
            \"type\": \"UnixHost\",
            \"address\": \"172.31.30.230\",
            \"toolkitPath\": \"/var/opt/delphix/toolkit\"
        }
    }
}"

echo "json: $json"

STATUS=`curl -sX POST -k --data @- ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
$json
EOF
`

echo "Environment: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

#########################################################
## Get Job Number ...

JOB=$( jqParse "${STATUS}" "job" )
echo "Job: ${JOB}"

jqJobStatus "${JOB}"            # Job Status Function ...

############## E O F ####################################
echo " "
echo "Done ..."
echo " "
exit 0

