#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2020 by Delphix. All rights reserved.
#
# Program Name : create_centos_env.sh
# Description  : Delphix API create environment 
# Author       : Alan Bitterman
# Created      : 2020-02-02
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: 
# ./create_centos_env.sh
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

DEF_DB_NAME=""           # 1
DEF_TARGET_ENV=""        # 2
DEF_TARGET_HOME=""       # 3
DEF_DELPHIX_GRP=""       # 4
DEF_MOUNT_PATH=""        # 5
DEF_DB_PORT=""           # 6

DEF_DB_NAME="pgSource"           # 1
DEF_TARGET_ENV="awsCentos"        # 2
DEF_TARGET_HOME="Postgres vFiles (10.12)"       # 3
DEF_DELPHIX_GRP="PostgreSQL"       # 4
DEF_MOUNT_PATH="/mnt/provision/${DEF_DB_NAME}"        # 5
DEF_DB_PORT="5434"           # 6



DEF_DB_USER="postgres"   # 7
DEF_DB_PASS="delphix"    # 8


#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## VDB Name from Command Line Parameters ...

DB_NAME="${1}"
ZTMP="Add DB Name"
if [[ "${DB_NAME}" == "" ]]
then
   if [[ "${DEF_DB_NAME}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      read DB_NAME
      if [[ "${DB_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      DB_NAME=${DEF_DB_NAME}
   fi
fi
echo "${ZTMP}: ${DB_NAME}"

#########################################################
## Get Environment ...

STATUS=`curl -sX GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."
#echo "environment: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_ENV="${2}"
if [[ "${TARGET_ENV}" == "" ]]
then
   ZTMP="Select Environment"
   if [[ "${DEF_TARGET_ENV}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select (.type=="UnixHostEnvironment" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_ENV
      if [[ "${TARGET_ENV}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_ENV=${DEF_TARGET_ENV}
   fi
fi

#
# Parse out reference for name of $TARGET_ENV ...
#
ENV_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'" and .namespace==null) | .reference '`
echo "environment reference: ${ENV_REFERENCE}"

if [[ "${ENV_REFERENCE}" == "" ]]
then
   echo "Environment Reference ${ENV_REFERENCE} not found, exiting ..."
   exit 1
fi

#
# Parse out primaryUser name ...
#
HOST_USER=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'" and .namespace==null) | .primaryUser '`
echo "primaryUser reference: ${HOST_USER}"

#########################################################
## Get Repository reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/repository -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "repository: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_HOME="${3}"
if [[ "${TARGET_HOME}" == "" ]]
then
   ZTMP="Target Home Repository"
   if [[ "${DEF_TARGET_HOME}" == "" ]]
   then    #.type=="OracleInstall" and 
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_HOME
      if [[ "${TARGET_HOME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_HOME=${DEF_TARGET_HOME}
   fi
fi

#
# Parse out reference for name of $ENV_REFERENCE ...
#
REP_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .name=="'"${TARGET_HOME}"'" and .namespace==null) | .reference '`
echo "repository reference: ${REP_REFERENCE}"
if [[ "${REP_REFERENCE}" == "" ]]
then
   echo "Error: No repository reference found for ${TARGET_ENV} and ${TARGET_HOME}, please verify values. Exiting ..."
   exit 1;
fi

#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
##echo "${STATUS}" | jq -r "."

SOURCE_CFG=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${DB_NAME}"'" and .namespace==null) | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

#########################################################
## Get Group Reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/group -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )

DELPHIX_GRP="${4}"
if [[ "${DELPHIX_GRP}" == "" ]]
then
   ZTMP="Target Delphix Group"
   if [[ "${DEF_DELPHIX_GRP}" == "" ]]
   then    
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read DELPHIX_GRP
      if [[ "${DELPHIX_GRP}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      DELPHIX_GRP=${DEF_DELPHIX_GRP}
   fi
fi

#
# Parse out group reference for name ${DELPHIX_GRP} ...
#
GROUP_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${DELPHIX_GRP}"'") | .reference '`
echo "group reference: ${GROUP_REF}"

#########################################################
## The Rest of the Command Line Parameters ...

#
# Staging NFS Mount Path on Source ...
#
MOUNT_PATH="${5}"
ZTMP="Mount Path Directory"
if [[ "${MOUNT_PATH}" == "" ]]
then
   if [[ "${DEF_MOUNT_PATH}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      echo "For Example: /mnt/provision/dsname"
      read MOUNT_PATH
      if [[ "${MOUNT_PATH}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      MOUNT_PATH=${DEF_MOUNT_PATH}
   fi
fi
echo "${ZTMP}: ${MOUNT_PATH}"

#
# Staging Database Port ...
#
DB_PORT="${6}"
ZTMP="Staging Database Port"
if [[ "${DB_PORT}" == "" ]]
then
   if [[ "${DEF_DB_PORT}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      echo "For Example: 5436"
      read DB_PORT
      if [[ "${DB_PORT}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      DB_PORT=${DEF_DB_PORT}
   fi
fi
echo "${ZTMP}: ${DB_PORT}"

#
# Database Username ...
#
DB_USER="${7}"
ZTMP="Database Username"
if [[ "${DB_USER}" == "" ]]
then
   if [[ "${DEF_DB_USER}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      read DB_USER
      if [[ "${DB_USER}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      DB_USER=${DEF_DB_USER}
   fi
fi
echo "${ZTMP}: ${DB_USER}"

#
# Database Username Password ...
#
DB_PASS="${8}"
ZTMP="Database Username Password"
if [[ "${DB_PASS}" == "" ]]
then
   if [[ "${DEF_DB_PASS}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      read DB_PASS
      if [[ "${DB_PASS}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      DB_PASS=${DEF_DB_PASS}
   fi
fi
## DEBUG ##echo "${ZTMP}: ${DB_PASS}"
echo "${ZTMP}: *******"

#########################################################
## vFiles link API Call ...

# ,"configSettingsStg":[{"propertyName":"listen_addresses","value":"*"}]
# ,"config_settings_Stg":[{"propertyName":"listen_addresses","value":"*"}]

DEF_DB_USER="postgres"
DEF_DB_PASS="delphix"
PARAMS="{\"UserName\":\"${DB_USER}\",\"UserPass\":\"${DB_PASS}\",\"postgresPort\":${DB_PORT}}"

json="{
    \"type\": \"LinkParameters\",
    \"name\": \"${DB_NAME}\",
    \"group\": \"${GROUP_REF}\",
    \"linkData\": {
        \"type\": \"AppDataStagedLinkData\",
        \"config\": \"${SOURCE_CFG}\",
        \"environmentUser\": \"${HOST_USER}\",
        \"parameters\": ${PARAMS},
        \"stagingEnvironment\": \"${ENV_REFERENCE}\",
        \"stagingEnvironmentUser\": \"${HOST_USER}\",
        \"stagingMountBase\": \"${MOUNT_PATH}\"
    }
}"

echo "JSON: ${json}"

echo "link API "
STATUS=`curl -s -X POST -k --data @- $BaseURL/database/link -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`

echo ${STATUS} | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

#########################################################
## Get Job Number ...

JOB=$( jqParse "${STATUS}" "job" )
echo "Job: ${JOB}"

#
# APPDATA link automatically submits a "sync" snapshot job, so increment previous JOB # by 1 and monitor ...
#
##JOB="JOB-511"
n=${JOB##*[!0-9]};
p=${JOB%%$n}
JOB=`echo "$p$((n+1))"`

echo "Job: ${JOB}"

jqJobStatus "${JOB}"            # Job Status Function ...


############## E O F ####################################
echo " "
echo "Done ..."
echo " "
exit 0



