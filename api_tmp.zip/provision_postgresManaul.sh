#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : provision_pgmanual.sh
# Description  : Delphix API for Provisioning a Postgres DB  
# Author       : Alan Bitterman
# Created      : 2019-12-12
# Version      : v1.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: 
#  ./provision_pgmanual.sh [vdb_name] [pg_port]       <-- add other parameters as needed with code changes
#
#########################################################
#                   DELPHIX CORP                        #
# Please make changes to the parameters below as req'd! #
#########################################################

#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#
# Command Line Parameters ....
# 

#
# Postgres VDB Name ...
#
VDB_NAME="${1}"
if [[ "${VDB_NAME}" == "" ]]
then
   VDB_NAME="pg_vdb"
fi

#
# Postgres Port ... 
#
PG_PORT=${2}
if [[ "${PG_PORT}" == "" ]]
then
   PG_PORT="5434"
fi

#
# Remaining Variables ... (hard coded for now)
#
APPDATA="pg_stage"				# Source DB
MOUNT_PATH="/mnt/provision/${VDB_NAME}"		# Mount Path
DELPHIX_GRP="Postgres"			# Delphix Group
SOURCE_ENV="linux3"				# Host Env
TK_NAME="PostgresManual vFiles (10.15)"		# Host Toolkit
LISTEN_ADDRESSES="*"            		# * for all .or. localhost .or.  ip1,ip2,etc.

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [[ "${RESULTS}" != "OK" ]]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get Group Reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/group -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )

#
# Parse out group reference for name ${DELPHIX_GRP} ...
#
GROUP_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${DELPHIX_GRP}"'") | .reference '`
echo "group reference: ${GROUP_REF}"

#########################################################
## Get Database ...

STATUS=`curl -s -X GET -k ${BaseURL}/database -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq "."

CONTAINER_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${APPDATA}"'" and .type=="AppDataContainer") | .reference '`
echo "container reference: ${CONTAINER_REF}"

#########################################################
## Get Environment primaryUser

STATUS=`curl -s -X GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`

#echo "Environment Status: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

#
# Parse out primaryUser for name of $SOURCE_ENV ...
#
PRIMARYUSER=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_ENV}"'") | .primaryUser '`
echo "primaryUser reference: ${PRIMARYUSER}"

ENV_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_ENV}"'") | .reference '`
echo "environment reference: ${ENV_REF}"

#########################################################
## Get repositor reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/repository -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq "."

REP_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TK_NAME}"'" and .environment=="'"${ENV_REF}"'") | .reference '`
echo "repository reference: ${REP_REF}"

#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq "."

SOURCE_CFG=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${APPDATA}"'") | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

#########################################################
## Provision AppData ...


#configSettingsStg
#config_settings_stg
# {\"propertyName\":\"listen_addresses\",\"value\":\"${LISTEN_ADDRESSES}\"
# , \"config_settings_stg\":[{\"propertyName\":\"listen_addresses\",\"value\":\"${LISTEN_ADDRESSES}\"}]
json="{
  \"container\":{
    \"sourcingPolicy\":{\"logsyncEnabled\":false,\"type\":\"SourcingPolicy\"}
    ,\"group\":\"${GROUP_REF}\"
    ,\"name\":\"${VDB_NAME}\"
    ,\"type\":\"AppDataContainer\"
  }
  ,\"source\":{
    \"operations\":{
       \"configureClone\":[]
       ,\"preRefresh\":[],\"postRefresh\":[],\"preRollback\":[],\"postRollback\":[],\"preSnapshot\":[]
       ,\"postSnapshot\":[],\"preStart\":[],\"postStart\":[],\"preStop\":[]
       ,\"postStop\":[{
           \"command\":\"sleep 25\",
           \"name\":\"stop_sleep\",
           \"type\":\"RunCommandOnSourceOperation\"
       }]
       ,\"type\":\"VirtualSourceOperations\"
    }
    ,\"parameters\": {\"postgresPort\":${PG_PORT},\"configSettingsStg\":[{\"propertyName\":\"listen_addresses\",\"value\":\"*\"}]}
    ,\"additionalMountPoints\":[]
    ,\"allowAutoVDBRestartOnHostReboot\":false
    ,\"name\":\"${VDB_NAME}\"
    ,\"type\":\"AppDataVirtualSource\"
  }
  ,\"sourceConfig\":{
    \"path\":\"${MOUNT_PATH}\"
    ,\"name\":\"${VDB_NAME}\"
    ,\"repository\":\"${REP_REF}\"
    ,\"linkingEnabled\":true
    ,\"parameters\": {}
    ,\"environmentUser\":\"${PRIMARYUSER}\"
    ,\"type\":\"AppDataDirectSourceConfig\"
  }
  ,\"timeflowPointParameters\":{
     \"type\": \"TimeflowPointSemantic\"
    ,\"container\": \"${CONTAINER_REF}\"
  }
  ,\"type\":\"AppDataProvisionParameters\"
}"

#   \"type\":\"TimeflowPointSnapshot\"
#   ,\"snapshot\":\"APPDATA_SNAPSHOT-26\"

echo "JSON: $json" 

echo " "
echo "Provision AppData ... "
STATUS=`curl -s -X POST -k --data @- $BaseURL/database/provision -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`

RESULTS=$( jqParse "${STATUS}" "status" )
echo ${STATUS} | jq "."

#########################################################
## Get Job Number ...

JOB=$( jqParse "${STATUS}" "job" )
echo "Job: ${JOB}"

jqJobStatus "${JOB}"            # Job Status Function ...

#########################################################
## The End is Here ...

echo " "
echo "Done "
exit 0;
