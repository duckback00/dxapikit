#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : link_appdata_i.sh
# Description  : Delphix API Add vFiles dSource 
# Author       : Alan Bitterman
# Created      : 2019-06-12
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: 
#
# ./link_appdata_i.sh [sourceconfig_name] [group] [host] 
# ./link_appdata_i.sh AppData AppData "Linux Host"
#
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

SOURCE_NAME="${1}"
DELPHIX_GRP="${2}"
SOURCE_ENV="${3}"

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [[ "${RESULTS}" != "OK" ]]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get Group Reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/group -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )

#
# Parse out group reference for name ${DELPHIX_GRP} ...
#
GROUP_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${DELPHIX_GRP}"'") | .reference '`
echo "group reference: ${GROUP_REF}"

#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq -r "."

#
# Parse out sourceconfig reference for name of $SOURCE_SID ...
#
# "type": "AppDataDirectSourceConfig",
# "namespace": null,

SOURCE_CFG=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_NAME}"'" and .namespace==null) | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

#########################################################
## Get Environment primaryUser

STATUS=`curl -s -X GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq -r "."

#
# Parse out primaryUser for name of $SOURCE_ENV ...
#
HOST_USER=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_ENV}"'") | .primaryUser '`
echo "primaryUser reference: ${HOST_USER}"

#########################################################
## vFiles link API Call ...

PARAMS="{}"    	# For Unstructured Files, there are no PARAMS ...

json="{
    \"type\": \"LinkParameters\",
    \"name\": \"${SOURCE_NAME}\",
    \"group\": \"${GROUP_REF}\",
    \"linkData\": {
        \"type\": \"AppDataDirectLinkData\",
        \"config\": \"${SOURCE_CFG}\",
        \"environmentUser\": \"${HOST_USER}\",
        \"parameters\": ${PARAMS}
    }
}"

echo "JSON: ${json}"

echo "vFiles link API "
STATUS=`curl -s -X POST -k --data @- $BaseURL/database/link -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`

echo ${STATUS} | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

#########################################################
## Get Job Number ...

JOB=$( jqParse "${STATUS}" "job" )
echo "Job: ${JOB}"

jqJobStatus "${JOB}"            # Job Status Function ...

#
# AppData link automatically submits a "sync" snapshot job, so increment previous JOB # by 1 and monitor ...
#
#JOB="JOB-511"
n=${JOB##*[!0-9]};
p=${JOB%%$n}
JOB=`echo "$p$((n+1))"`

echo "Job: ${JOB}"

jqJobStatus "${JOB}"            # Job Status Function ...


# 
# The End is Here ...
#
echo " "
echo "Done "
exit 0;
