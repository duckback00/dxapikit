#!/bin/bash
#
# Linux DSIL Hostchecker 
#

# 
# Application Variables ...
#
WHO=`whoami`
HOST_IP=`hostname -i`
LS=`which ls` 
AWK=`which awk`
SUDO=`which sudo`
PS=`which ps`
DT=`date '+%Y%m%d%H%M%S'`
JSON=""

#
# Opening Message ... 
#
echo "Linux DSIL Hostchecker v1.0"
echo "Run as the Delphix Operating System Account"
echo " "

#
# Source or Target ...
#
HOST=""
while [[ "${HOST}" != "source" ]] && [[ "${HOST}" != "target" ]] 
do
   echo "Please enter whether this machine is a source or target: "
   read HOST
   HOST=$(echo "${HOST}" | tr '[:upper:]' '[:lower:]')
done
echo " "

#
# While Loop Tests ...
# 
CHECK="TEST"
let TEST=1
let MAXTEST=7
while [[ "${CHECK}" != "q" ]]
do

   #
   # Prompt for Test # or increment Test # if ALL ...
   #
   if [[ "${CHECK}" == "ALL" ]]
   then
      let TEST=TEST+1
   else
      echo "======================= On ${HOST} as ${WHO} =========================="
      echo "1. Check Home Directory Permissions"
      echo "2. Check the Postgres Installation"
      echo "3. Check network port access"
      echo "4. Check for local ssh connectivity"
      echo "5. Check sshd_config for timeout configuration"
      echo "6. Check user sudo privileges"
      echo "7. Check toolkit path"
      echo "Please enter check # or ALL or q to Quit: "  
      read CHECK
      if [[ "${CHECK}" != "ALL" ]] && [[ "${CHECK}" != "q" ]] && [[ "${CHECK}" != "" ]]
      then
         let TEST=$CHECK
      fi
   fi

   # 
   # Done/Exit/Quit ...
   #
   if [[ "${CHECK}" == "q" ]] 
   then
      echo "Quit, Bye ..."
      exit 0
   fi
   if [[ "${CHECK}" == "ALL" ]] && [[ $TEST -gt $MAXTEST ]]
   then
      echo "ALL Done, Bye-Bye ..."
      exit 0
   fi

if [[ "${CHECK}" != "" ]] & [[ $TEST -ge 1 ]] && [[ $TEST -le $MAXTEST ]]
then

   echo "Running Test Number $TEST ..."

   #
   # echo "1. Check Home Directory Permissions"
   #
   if [[ $TEST -eq 1 ]] 
   then
      echo "Test #${TEST} ..."
      echo "Checking \$HOME ${HOME} ..."
      STR=$($LS -ld --time-style=long-iso $HOME)
      #STR=$($LS -ld --time-style=long-iso /home/oracle)
      #drwxr-xr-x. 12 delphix oinstall 4096 2018-02-17 18:38 /home/delphix
      #lrwxrwxrwx 1 root root 11 2014-11-22 22:22 /home/oracle -> /u02/oracle
      #echo "ls -ld: ${STR}"
      LINK="${STR:0:1}"
      echo "Symbolic Link or Directory: ${LINK}" 
      if [[ "${LINK}" == "l" ]]
      then 
         PATH=`echo "${STR}" | $AWK -F" " '{print $10}'`
         echo "Actual Path: ${PATH}"
         if [[ -d "${PATH}" ]]
         then
            STR=$($LS -ld --time-style=long-iso $PATH)
         else
            echo "Error: Symbolic Link Path ${PATH} is not a Directory"
         fi
      fi
      echo "ls -ld: ${STR}"
      OWNER="${STR:1:3}"
      GROUP="${STR:4:3}"
      G1="${STR:4:1}"
      REST="${STR:7:3}"
      GROUP2=`echo "${STR}" | $AWK -F" " '{print $4}'`
      echo "Owner: $OWNER    Group: $GROUP    Rest: $REST "
      echo "Primary Group: ${GROUP2}"
      if [[ "${OWNER}" == "rwx" ]] && [[ "${G1}" == "r" ]] 
      then
         #if  [[ "${GROUP2}" == "oinstall" ]] || [[ "${GROUP2}" == "dba" ]]  
         #then
            echo "Home Directory Check ... ALL OK"
         #else
         #   echo "Error: Please Check Primary Group Membership"
         #fi
      else 
         echo "Error: Please Check Directory Permissions"
      fi
   fi

   #
   # echo "2. Check the Postgres Installation"
   # 
   if [[ ${TEST} -eq 2 ]] 
   then
      echo "Test #${TEST} ..."
   fi

   # 
   # echo "3. Check network port access"
   # 
   if [[ ${TEST} -eq 3 ]] 
   then
      echo "Test #${TEST} ..."
   fi

   # 
   # echo "4. Check for local ssh connectivity"
   # 
   if [[ ${TEST} -eq 4 ]] 
   then
      # echo "Test #${TEST} ..."
      # Note: From Delphix Engine to Source/Target Test ...
      # ssh -i /etc/ssh/ssh_host_rsa_key delphix_os@10.241.147.141 '/bin/sh -c uname -sr'
      # 
      # Local ssh connection ...
      #
      RESULTS=$( ssh ${WHO}@${HOST_IP} '/bin/sh -c uname -sr' )
      echo "ssh results:"
      echo "${RESULTS}"
      if [[ "${RESULTS}" == "Linux" ]]
      then
         echo "local ssh connection: OK"
      else
         echo "Error: Unknown ssh response, please investigate ..."
      fi
   fi
 
   # 
   # echo "5. Check sshd_config for timeout configuration"
   # 
   if [[ ${TEST} -eq 5 ]] 
   then
      echo "Test #${TEST} ..."
   fi

   # 
   # echo "6. Check user sudo privileges"
   # 
   if [[ ${TEST} -eq 6 ]] 
   then
      echo "Test #${TEST} ..."
      RESULTS=$( $SUDO -l )
      echo "$SUDO -l Results: "
      echo "${RESULTS}"
#Matching Defaults entries for delphix on this host:
#    requiretty, !visiblepw, always_set_home, env_reset, env_keep="COLORS DISPLAY HOSTNAME HISTSIZE INPUTRC KDEDIR LS_COLORS", env_keep+="MAIL PS1 PS2 QTDIR USERNAME LANG LC_ADDRESS LC_CTYPE", env_keep+="LC_COLLATE LC_IDENTIFICATION LC_MEASUREMENT LC_MESSAGES", env_keep+="LC_MONETARY LC_NAME LC_NUMERIC LC_PAPER LC_TELEPHONE", env_keep+="LC_TIME LC_ALL LANGUAGE LINGUAS _XKB_CHARSET XAUTHORITY", secure_path=/sbin\:/bin\:/usr/sbin\:/usr/bin, !requiretty

#User delphix may run the following commands on this host:
#    (root) NOPASSWD: ALL


      #
      # /bin/ps 
      #
      RESULTS=$( sudo $PS -ef | grep [s]udo )
      echo "$PS Results: "
      echo "${RESULTS}"

   fi

   # 
   # echo "7. Check toolkit path"
   # 
   if [[ ${TEST} -eq 7 ]] 
   then
      echo "Test #${TEST} ..."
      echo "Please enter Delphix ${HOST} Toolkit Path: "
      read TKPATH
      if [[ -d "${TKPATH}" ]]
      then
         STR=$($LS -ld --time-style=long-iso $TKPATH)
         #drwxr-xr-x. 12 delphix oinstall 4096 2018-02-17 18:38 /home/delphix
         echo "ls -ld: ${STR}"
         OWNER="${STR:1:3}"
         GROUP="${STR:4:3}"
         REST="${STR:7:3}"
         GROUP2=`echo "${STR}" | $AWK -F" " '{print $4}'`
         echo "Owner: $OWNER    Group: $GROUP    Rest: $REST "
         echo "Primary Group: ${GROUP2}"
         if [[ "${OWNER}" == "rwx" ]] && [[ "${GROUP}" == "rwx" ]] 
         then
            echo "Home Directory Check ... ALL OK"
         else
            echo "Error: Toolkit Path Permissions need to be 770 or greater ..."
         fi
      else
         echo "Error: Invalid Toolkit Path, ${TKPATH} is not a directory ..."
      fi
   fi

   echo " "
else 
   echo "Invalid Test Request, ${CHECK}, Please try again ..."
fi      # end if null 
done       # CHECK loop ...

#
# The End ...
#
exit
