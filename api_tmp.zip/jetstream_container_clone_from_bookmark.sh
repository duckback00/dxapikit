#!/bin/bash
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : jetstream_container_clone_from_bookmark.sh
# Description  : Delphix API to clone a container from a bookmark
# Author       : Alan Bitterman
# Created      : 2019-09-15
# Version      : v1.0
# Valid Since  : Session Version 1.9.0 - Delphix Engine Version 5.2
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#  3.) Include ./jqJSON_subroutines.sh
#  4.) Change values below as required
#
# Interactive Usage: 
# ./jetstream_container_clone_from_bookmark.sh
#
# Non-interactive Usage:
# ./jetstream_container_clone_from_bookmark.sh [template_name] [container_name] [bookmark_name] 
#
#########################################################
#                   DELPHIX CORP                        #
# Please make changes to the parameters below as req'd! #
#########################################################

#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#
# Default Values if not provided on Command Line ...
#
# For non-interactive defaults ...
#
#DEF_JS_TEMPLATE="tpl"           # Jetstream Template Name
#DEF_JS_CONTAINER_NAME="dc"      # Jetstream Container Name
#DEF_JS_BOOK_NAME="BM1"          # Jetstream Bookmark Name
#DEF_NEW_CONTAINER_NAME="dc3"    # New Container Name 
#
# For full interactive option, set default values to nothing ...
#
DEF_JS_TEMPLATE=""
DEF_JS_CONTAINER_NAME=""
DEF_JS_BOOK_NAME=""
DEF_NEW_CONTAINER_NAME=""

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Session and Login ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [[ "${RESULTS}" != "OK" ]]
then
   echo "Error: Exiting ..."
   exit 1;
fi

#########################################################
## Get API Version Info ...

APIVAL=$( jqGet_APIVAL )
if [[ "${APIVAL}" == "" ]]
then
   echo "Error: Delphix Engine API Version Value Unknown ${APIVAL} ..."
else
   echo "Delphix Engine API Version: ${APIVAL}"
fi

#########################################################
## Get Template Reference ...

#echo "Getting Jetstream Template Reference ..."
STATUS=`curl -s -X GET -k ${BaseURL}/jetstream/template -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq "."

JS_TEMPLATE="${1}"
if [[ "${JS_TEMPLATE}" == "" ]]
then
   ZTMP="Template Name"
   if [[ "${DEF_JS_TEMPLATE}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read JS_TEMPLATE
      if [[ "${JS_TEMPLATE}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      JS_TEMPLATE="${DEF_JS_TEMPLATE}"
   fi
fi
echo "template name: ${JS_TEMPLATE}"

#
# Parse ...
#
JS_TPL_REF=`echo "${STATUS}" | jq --raw-output '.result[] | select(.name=="'"${JS_TEMPLATE}"'") | .reference '`
echo "template reference: ${JS_TPL_REF}"

if [[ "${JS_TPL_REF}" == "" ]]
then
   echo "${ZTMP} Reference ${JS_TPL_REF} for ${JS_TEMPLATE} not found, Exiting ..."
   exit 1
fi

#JS_ACTIVE_BRANCH_REF=`echo "${STATUS}" | jq --raw-output '.result[] | select(.name=="'"${JS_TEMPLATE}"'") | .activeBranch '`
#echo "active template branch reference: ${JS_ACTIVE_BRANCH_REF}"

#########################################################
## Get container reference...

#echo "Getting Jetstream Template Container Reference ..."
CONTAINERS=`curl -s -X GET -k ${BaseURL}/jetstream/container -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${CONTAINERS}" "status" )
#echo "${STATUS}" | jq "."

JS_CONTAINER_NAME="${2}"
if [[ "${JS_CONTAINER_NAME}" == "" ]]
then
   ZTMP="Container Name"
   if [[ "${DEF_JS_CONTAINER_NAME}" == "" ]]
   then
      TMP=`echo "${CONTAINERS}" | jq --raw-output '.result[] | select (.template=="'"${JS_TPL_REF}"'") | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read JS_CONTAINER_NAME
      if [[ "${JS_CONTAINER_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      JS_CONTAINER_NAME="${DEF_JS_CONTAINER_NAME}"
   fi
fi
echo "template container name: ${JS_CONTAINER_NAME}"

JS_CONTAINER_REF=`echo "${CONTAINERS}" | jq --raw-output '.result[] | select(.template=="'"${JS_TPL_REF}"'" and .name=="'"${JS_CONTAINER_NAME}"'") | .reference '`
echo "template container reference: ${JS_CONTAINER_REF}"

if [[ "${JS_CONTAINER_REF}" == "" ]]
then
   echo "${ZTMP} Reference ${JS_CONTAINER_REF} for ${JS_CONTAINER_NAME} not found, Exiting ..."
   exit 1
fi

JS_DC_ACTIVE_BRANCH=`echo "${CONTAINERS}" | jq --raw-output '.result[] | select(.template=="'"${JS_TPL_REF}"'" and .name=="'"${JS_CONTAINER_NAME}"'") | .activeBranch '`
echo "Container Active Branch Reference: ${JS_DC_ACTIVE_BRANCH}"

#########################################################
## Get Active Branch Reference ...

#echo "Getting Jetstream Branch Reference Value ..."
STATUS=`curl -s -X GET -k ${BaseURL}/jetstream/branch/${JS_DC_ACTIVE_BRANCH} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq "."

ACTIVE_BRANCH_NAME=`echo "${STATUS}" | jq --raw-output '.result.name'`
echo "Active Branch Name: ${ACTIVE_BRANCH_NAME}"

#
# Must use Active Branch ...
#
JS_BRANCH_REF="${JS_DC_ACTIVE_BRANCH}"

if [[ "${JS_BRANCH_REF}" == "" ]]
then
   echo "Branch Reference ${JS_BRANCH_REF} for Active Branch not found, Exiting ..."
   exit 1
fi

#########################################################
## Get BookMarks per Branch Option ...

STATUS=`curl -s -X GET -k ${BaseURL}/jetstream/bookmark -b "${COOKIE}" -H "${CONTENT_TYPE}"`
##STATUS=`curl -s -X GET -k ${BaseURL}/jetstream/bookmark?container=${JS_CONTAINER_REF} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq "."

JS_BOOK_NAME="${3}"
if [[ "${JS_BOOK_NAME}" == "" ]]
then
   ZTMP="Bookmark Name"
   if [[ "${DEF_JS_BOOK_NAME}" == "" ]]
   then
#      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.container=="'"${JS_CONTAINER_REF}"'" and .branch=="'"${JS_BRANCH_REF}"'") | .name '`
TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.template=="'"${JS_TPL_REF}"'") | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read JS_BOOK_NAME
      if [[ "${JS_BOOK_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      JS_BOOK_NAME="${DEF_JS_BOOK_NAME}"
   fi
fi
echo "bookmark name: ${JS_BOOK_NAME}"

#
# Parse ...
#
##JS_BOOK_REF=`echo "${STATUS}" | jq --raw-output '.result[] | select(.container=="'"${JS_CONTAINER_REF}"'" and .branch=="'"${JS_BRANCH_REF}"'" and .name=="'"${JS_BOOK_NAME}"'") | .reference '`

JS_BOOK_REF=`echo "${STATUS}" | jq --raw-output '.result[] | select(.template=="'"${JS_TPL_REF}"'" and .name=="'"${JS_BOOK_NAME}"'") | .reference '`

#
# Validate ...
#
if [[ "${JS_BOOK_REF}" == "" ]]
then
   echo "No Bookmark Name/Reference ${JS_BOOK_NAME}/${JS_BOOK_REF} found, Exiting ..."
   exit 1;
fi

echo "Bookmark Reference: ${JS_BOOK_REF}"

#########################################################
## bookmark/reference

echo "${BaseURL}/jetstream/bookmark/${JS_BOOK_REF}"
STATUS=`curl -s -X GET -k ${BaseURL}/jetstream/bookmark/${JS_BOOK_REF} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
##RESULTS=$( jqParse "${STATUS}" "status" )
##echo "${STATUS}"
###echo "${STATUS}" | jq "."

SHARED=`echo "${STATUS}" | jq --raw-output '.result.shared'`
echo "Bookmark Shared: ${SHARED}"

#if [[ "${SHARED}" == "false" ]]
#then
#   echo "Bookmark needs to be shared to clone container, exiting ..."
#   exit 1
#fi

#########################################################
## New or Existing Container Name ...

NEW_CONTAINER_NAME="${4}"
if [[ "${NEW_CONTAINER_NAME}" == "" ]]
then
   ZTMP="Container Name"
   if [[ "${DEF_NEW_CONTAINER_NAME}" == "" ]]
   then
      TMP=`echo "${CONTAINERS}" | jq --raw-output '.result[] | select (.template=="'"${JS_TPL_REF}"'") | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read NEW_CONTAINER_NAME
      if [[ "${NEW_CONTAINER_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      NEW_CONTAINER_NAME="${DEF_NEW_CONTAINER_NAME}"
   fi
fi

CHK=`echo "${CONTAINERS}" | jq --raw-output '.result[] | select (.name=="'"${NEW_CONTAINER_NAME}"'")'`
echo "CHK: $CHK"

if [[ "${CHK}" != "" ]]
then
   echo "Error: Container Name already Exists, please try again with Unique Container Name ..."
   exit 1
fi

#########################################################
## DataSource ...

#echo "${BaseURL}/selfservice/datasource?dataLayout=${JS_CONTAINER_REF}"
STATUS=`curl -s -X GET -k ${BaseURL}/selfservice/datasource?dataLayout=${JS_CONTAINER_REF} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#RESULTS=$( jqParse "${STATUS}" "status" )
echo "${STATUS}" | jq "."

#DB_CONTAINER_REF=`echo "${STATUS}" | jq --raw-output '.result[0].container'`
#echo "db container: ${DB_CONTAINER_REF}"

#"name": "VAppData",
DB_NAME=`echo "${STATUS}" | jq --raw-output '.result[0].name'`
echo "db name: ${DB_NAME}"

## NOTE:  I just extracted the VDB name from the ACTION details ...

RTMP=$RANDOM
TPL="tpl${RTMP}"
DS="ds${RTMP}"
CLONE="${DB_NAME}${RTMP}"
TAGS="\"${JS_BOOK_NAME}\""
ENV="172.16.129.133"  ###"Linux Host"

#
# VAppData
#
echo "./provision_appdata_i.sh ${DB_NAME} ${CLONE} AppData \"${ENV}\" \"Unstructured Files\" /mnt/provision/${CLONE}"
./provision_appdata_i.sh ${DB_NAME} ${CLONE} AppData "${ENV}" "Unstructured Files" /mnt/provision/${CLONE}

###./provision_oracle_vcs.sh orcl $CLONE "Oracle_Targets" "172.16.129.133" "/u01/app/oracle/product/11.2.0.4/db_1" "/mnt/provision" "200M" "false"

echo "./jetstream_template_create_jq.sh ${TPL} ${DB_NAME} ${DS}"
./jetstream_template_create_jq.sh ${TPL} ${DB_NAME} ${DS}

echo "./jetstream_container_create_jq.sh ${TPL} ${DS} ${CLONE} ${NEW_CONTAINER_NAME}"
./jetstream_container_create_jq.sh ${TPL} ${DS} ${CLONE} ${NEW_CONTAINER_NAME}
./jetstream_bookmark_create_from_latest_jq.sh ${TPL} ${NEW_CONTAINER_NAME} "${JS_BOOK_NAME}" false "${TAGS}"

############## E O F ####################################
echo " "
echo "Done ..."
echo " "
exit 0

