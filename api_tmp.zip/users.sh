#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : users.sh
# Description  : Delphix API about call 
# Author       : Alan Bitterman
# Created      : 2017-08-12
# Version      : v1.1 2019-05-09
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: ./users.sh
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [[ "${RESULTS}" != "OK" ]]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1
fi

echo "Session and Login Successful ..."

#########################################################
## User API Call ...

echo " "
echo "User API "
STATUS=`curl -s -X GET -k ${BaseURL}/user -b "${COOKIE}" -H "${CONTENT_TYPE}"`
echo ${STATUS} | jq "."

#########################################################
## Some jq parsing examples ...

ADMIN_REF=`echo "${STATUS}" | jq --raw-output ".result[] | select (.name == \"delphix_admin\") | .reference"`
echo "delphix_admin User Reference: ${ADMIN_REF}"

USERS=`echo "${STATUS}" | jq --raw-output ".result[].name"`
echo "List All User Names: ${USERS}"

#USERS="[\"delphix_admin\",\"dev\"]"
#TMP=`echo "$USERS" | jq --raw-output ".[]"`
#echo "$TMP"

#
# Process Arrays using jq ...
#
echo "All User Name References for JSON purposes ..."
REFS="["
DELIM=""
while read usr
do
   echo "|${usr}|"
   Z=`echo "${STATUS}" | jq --raw-output ".result[] | select (.name == \"${usr}\") | .reference"`
   if [[ "${Z}" != "" ]]
   then
      #REFS="${REFS}${DELIM}\"${Z}\""	    # quoted
      REFS="${REFS}${DELIM}"'\"'${Z}'\"'    # quotes escaped
      DELIM=","
   fi
done <<< "${USERS}"       ### "$TMP"
REFS="${REFS}]"
echo "References: ${REFS}"

# 
# The End is Hear ...
#
echo " "
echo "Done "
exit 0;
