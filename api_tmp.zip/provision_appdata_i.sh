#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : provision_appdata_i.sh
# Description  : Delphix API Provision vFile dSource (AppData) 
# Author       : Alan Bitterman
# Created      : 2019-06-12
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage:
#
#  ./provision_appdata_i.sh [dSource] [VDB_Name] [Group] [Env] [Repository] [mountPath]
#  ./provision_appdata_i.sh AppData VAppData AppData "Linux Host" "Unstructured Files" /mnt/provision/VAppData
#
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [[ "${RESULTS}" != "OK" ]]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get database container ...

STATUS=`curl -s -X GET -k ${BaseURL}/database -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "database: ${STATUS}"
#echo "${STATUS}" | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

SOURCE_SID="${1}"
if [[ "${SOURCE_SID}" == "" ]]
then
   ZTMP="Enter dSource or VDB Name to Provision"
   if [[ "${DEF_SOURCE_SID}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select (.namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SOURCE_SID
      if [[ "${SOURCE_SID}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SOURCE_SID=${DEF_SOURCE_SID}
   fi
fi

#
# Parse out container reference for name of $SOURCE_SID ...
#
CONTAINER_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_SID}"'" and .namespace==null) | .reference '`
echo "container reference: ${CONTAINER_REFERENCE}"
if [[ "${CONTAINER_REFERENCE}" == "" ]]
then
   echo "Error: No container found for ${SOURCE_SID} ${CONTAINER_REFERENCE}, Exiting ..."
   exit 1;
fi

#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq -r "."

#
# Parse out sourceconfig reference for name of $SOURCE_SID ...
#
# "type": "AppDataDirectSourceConfig",
# "namespace": null,

SOURCE_CFG=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_SID}"'" and .namespace==null) | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

#########################################################
## VDB Name from Command Line Parameters ...

VDB_NAME="${2}"
ZTMP="New VDB Name"
if [[ "${VDB_NAME}" == "" ]]
then
   if [[ "${DEF_VDB_NAME}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      read VDB_NAME
      if [[ "${VDB_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      VDB_NAME=${DEF_VDB_NAME}
   fi
fi
echo "${ZTMP}: ${VDB_NAME}"

#########################################################
## Get Group Reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/group -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "group: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

DELPHIX_GRP="${3}"
if [[ "${DELPHIX_GRP}" == "" ]]
then
   ZTMP="Delphix Target Group/Folder"
   if [[ "${DEF_DELPHIX_GRP}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select (.namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read DELPHIX_GRP
      if [[ "${DELPHIX_GRP}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      DELPHIX_GRP=${DEF_DELPHIX_GRP}
   fi
fi

#
# Parse out group reference for name ${DELPHIX_GRP} ...
#
GROUP_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${DELPHIX_GRP}"'" and .namespace==null) | .reference '`
echo "group reference: ${GROUP_REFERENCE}"

#########################################################
## Get Environment reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_ENV="${4}"
if [[ "${TARGET_ENV}" == "" ]]
then
   ZTMP="Target Environment"
   if [[ "${DEF_TARGET_ENV}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select (.type=="UnixHostEnvironment" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_ENV
      if [[ "${TARGET_ENV}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_ENV=${DEF_TARGET_ENV}
   fi
fi

#
# Parse out reference for name of $TARGET_ENV ...
#
ENV_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'" and .namespace==null) | .reference '`
echo "env reference: ${ENV_REFERENCE}"

#
# Parse out primaryUser for name of $SOURCE_ENV ...
#
HOST_USER=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'") | .primaryUser '`
echo "primaryUser reference: ${HOST_USER}"

#########################################################
## Get Repository reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/repository -b "${COOKIE}" -H "${CONTENT_TYPE}"`
##echo "${STATUS}" | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_HOME="${5}"
if [[ "${TARGET_HOME}" == "" ]]
then
   ZTMP="Target Repository"
   if [[ "${DEF_TARGET_HOME}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.type=="AppDataRepository" and .environment=="'"${ENV_REFERENCE}"'" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_HOME
      if [[ "${TARGET_HOME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_HOME=${DEF_TARGET_HOME}
   fi
fi

#
# Parse out reference for name of $ENV_REFERENCE ...
#
REP_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .name=="'"${TARGET_HOME}"'" and .namespace==null) | .reference '`
echo "repository reference: ${REP_REFERENCE}"
if [[ "${REP_REFERENCE}" == "" ]]
then
   echo "Error: No repository reference found for ${TARGET_ENV} and ${TARGET_HOME}, please verify values. Exiting ..."
   exit 1;
fi

#########################################################
## Get Remaining Command Line Parameters ...

MOUNT_BASE="${6}"
ZTMP="Mount Path"
if [[ "${MOUNT_BASE}" == "" ]]
then
   if [[ "${DEF_MOUNT_BASE}" == "" ]]
   then
      echo "Example: /mnt/provision"
      echo "---------------------------------"
      echo "Please Enter ${ZTMP}: "
      read MOUNT_BASE
      if [[ "${MOUNT_BASE}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      MOUNT_BASE=${DEF_MOUNT_BASE}
   fi
fi
echo "${ZTMP}: ${MOUNT_BASE}"

#########################################################
## database provision API Call ...

json="{
    \"type\": \"AppDataProvisionParameters\",
    \"container\": {
        \"type\": \"AppDataContainer\",
        \"name\": \"${VDB_NAME}\",
        \"group\": \"${GROUP_REFERENCE}\"
    },
    \"source\": {
        \"type\": \"AppDataVirtualSource\",
        \"name\": \"${VDB_NAME}\",
        \"config\": \"${SOURCE_CFG}\",
        \"parameters\": {},
        \"allowAutoVDBRestartOnHostReboot\": true
    },
    \"sourceConfig\": {
        \"type\": \"AppDataDirectSourceConfig\",
        \"name\": \"${VDB_NAME}\",
        \"environmentUser\": \"${HOST_USER}\",
        \"repository\": \"${REP_REFERENCE}\",
        \"path\": \"${MOUNT_BASE}\"
    },
    \"timeflowPointParameters\": {
        \"type\": \"TimeflowPointSemantic\",
        \"container\": \"${CONTAINER_REFERENCE}\"
    }
}"

echo "JSON: ${json}" 

echo "vFiles provision API "
STATUS=`curl -s -X POST -k --data @- $BaseURL/database/provision -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`

echo ${STATUS} | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

#########################################################
## Get Job Number ...

JOB=$( jqParse "${STATUS}" "job" )
echo "Job: ${JOB}"

jqJobStatus "${JOB}"            # Job Status Function ...

# 
# The End is Here ...
#
echo " "
echo "Done "
exit 0;
