#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2020 by Delphix. All rights reserved.
#
# Program Name : delete_env.sh
# Description  : Delphix API delete environment 
# Author       : Alan Bitterman
# Created      : 2020-02-02
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: 
# ./delete_env.sh [environment_name]
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

TARGET_ENV=""
DEF_TARGET_ENV="" 

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."


#########################################################
## Delete Environment ...

STATUS=`curl -sX GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."
#echo "environment: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_ENV="${1}"
if [[ "${TARGET_ENV}" == "" ]]
then
   ZTMP="Delete Environment"
   if [[ "${DEF_TARGET_ENV}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select (.type=="UnixHostEnvironment" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_ENV
      if [[ "${TARGET_ENV}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_ENV=${DEF_TARGET_ENV}
   fi
fi

#
# Parse out reference for name of $TARGET_ENV ...
#
ENV_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'" and .namespace==null) | .reference '`
echo "environment reference: ${ENV_REFERENCE}"

if [[ "${ENV_REFERENCE}" != "" ]] 
then

   STATUS=`curl -sX POST -k --data @- ${BaseURL}/environment/${ENV_REFERENCE}/delete -b "${COOKIE}" -H "${CONTENT_TYPE}"  <<EOF
{
}
EOF
`

   echo "Environment: ${STATUS}"
   RESULTS=$( jqParse "${STATUS}" "status" )

else
   echo "Environment Reference ${ENV_REFERENCE} not found, exiting ..."
   exit 1
fi
 
#########################################################
## Get Job Number ...

JOB=$( jqParse "${STATUS}" "job" )
echo "Job: ${JOB}"

jqJobStatus "${JOB}"            # Job Status Function ...

############## E O F ####################################
echo " "
echo "Done ..."
echo " "
exit 0



