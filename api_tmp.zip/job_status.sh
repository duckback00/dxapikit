#!/bin/bash
#

#########################################################
## Subroutines ...

##. ./jqJSON_subroutines.sh
. /Users/abitterman/Development/APIs/book/API/jqJSON_subroutines.sh
#########################################################
## Parameter Initialization ...

##. ./delphix_engine.conf
. /Users/abitterman/Development/APIs/book/API/delphix_engine.conf

#########################################################
## Command Line Arguments ...

JOB=${1}
MONITOR=${2}           # YES or other ...
if [[ "${3}" != "" ]]
then
   DELAYTIMESEC=${3}
else
   DELAYTIMESEC=10
fi

#########################################################
## Host Operating System Application Variables ...

#
# Set GDT Environment Variable for GNU Date if exists ...
#
which gdate 1> /dev/null 2> /dev/null
if [ $? -eq 0 ]
then
   GDT=gdate
else
   GDT=date
fi
export GDT
#echo "Date Command: ${GDT}"

#
# Operating System ...
#
case "$OSTYPE" in
  solaris*) OS="SOLARIS" ;;
  darwin*) OS="MAC" ;;
  linux*) OS="LINUX" ;;
  bsd*) OS="BSD" ;;
  aix*) OS="AIX" ;;
  msys*) OS="WIN" ;;
  *) echo "unknown: $OSTYPE" ;;
esac
#echo "OSTYPE: $OSTYPE ... OS: $OS"

#########################################################
## Authentication ...

#echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ..."
   exit 1;
fi

#########################################################
## Job Information ...

if [ "${JOB}" != "" ]
then

JOB_STATUS=`curl -s -X GET -k ${BaseURL}/job/${JOB} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${JOB_STATUS}" "status" )
#echo "json> $JOB_STATUS"
#echo "${JOB_STATUS}" | jq "."

#########################################################
#
# Get Job State from Results, loop until not RUNNING  ...
#
JOBSTATE=$( jqParse "${JOB_STATUS}" "result.jobState" )
PERCENTCOMPLETE=$( jqParse "${JOB_STATUS}" "result.percentComplete" )
#echo "Current status as of" $(date) ": ${JOBSTATE} ${PERCENTCOMPLETE}% Completed"
STARTTIME=$( jqParse "${JOB_STATUS}" "result.startTime" )
UPDATETIME=$( jqParse "${JOB_STATUS}" "result.updateTime" )
#
# Format Start/End Timestamps ...
#
str3=${STARTTIME:0:19}
str3=${str3//T/ }
str4=${UPDATETIME:0:19}
str4=${str4//T/ }
#
# Compute Timestamp Difference ...
#
if [[ "${OS}" == "MAC" ]]
then
   secs=$(((`date -jf "%Y-%m-%d %H:%M:%S" "${str4}" +%s` - `date -jf "%Y-%m-%d %H:%M:%S" "${str3}" +%s`)))
else
secs=$((( $(${GDT} --date="${str4}" +%s) - $(${GDT} --date="${str3}" +%s) )))
fi
MINS=$(echo "scale=2; ( $secs )/(60) " | bc)
if [[ "${MONITOR}" == "YES" ]]
then
   echo "{ \"results\": ["
fi

#
# Individual Job Request returns a single JSON object ...
#
echo "{ 
  \"job\": \"${JOB}\",
  \"startTime\": \"${STARTTIME}\",
  \"updateTime\": \"${UPDATETIME}\",
  \"durationTimeSecs\": \"${secs}\",
  \"durationTimeMins\": \"${MINS}\",
  \"JobState\": \"${JOBSTATE}\",
  \"PercentComplete\": \"${PERCENTCOMPLETE}\"
}"

#
# Monitor ...
#
if [[ "${MONITOR}" == "YES" ]]
then
   while [ "${JOBSTATE}" == "RUNNING" ]
   do
      sleep ${DELAYTIMESEC}
      JOB_STATUS=`curl -s -X GET -k ${BaseURL}/job/${JOB} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
      JOBSTATE=$( jqParse "${JOB_STATUS}" "result.jobState" )
      PERCENTCOMPLETE=$( jqParse "${JOB_STATUS}" "result.percentComplete" )
      #echo "Current status as of" $(date) ": ${JOBSTATE} ${PERCENTCOMPLETE}% Completed"
      STARTTIME=$( jqParse "${JOB_STATUS}" "result.startTime" )
      UPDATETIME=$( jqParse "${JOB_STATUS}" "result.updateTime" )
      #
      # Format Start/End Timestamps ...
      #
      str3=${STARTTIME:0:19}
      str3=${str3//T/ }
      str4=${UPDATETIME:0:19}
      str4=${str4//T/ }
      #
      # Compute Timestamp Difference ...
      #
      if [[ "${OS}" == "MAC" ]]
      then
         secs=$(((`date -jf "%Y-%m-%d %H:%M:%S" "${str4}" +%s` - `date -jf "%Y-%m-%d %H:%M:%S" "${str3}" +%s`)))
      else
         secs=$((( $(${GDT} --date="${str4}" +%s) - $(${GDT} --date="${str3}" +%s) )))
      fi
      MINS=$(echo "scale=2; ( $secs )/(60) " | bc)
      echo ",{
  \"job\": \"${JOB}\",
  \"startTime\": \"${STARTTIME}\",
  \"updateTime\": \"${UPDATETIME}\",
  \"durationTimeSecs\": \"${secs}\",
  \"durationTimeMins\": \"${MINS}\",
  \"JobState\": \"${JOBSTATE}\",
  \"PercentComplete\": \"${PERCENTCOMPLETE}\"
}"
   done

   #########################################################
   ##  Producing final status

   if [ "${JOBSTATE}" != "COMPLETED" ]
   then
      echo "Error: Delphix Job Did not Complete, please check GUI ${JOB_STATUS}"
      #exit 1
   fi

   echo "]}"

fi      # end if $MONITOR

fi 	# end if $JOB

############## E O F ####################################
exit 0;

