#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2021 by Delphix. All rights reserved.
#
# Program Name : env_user_update.sh
# Description  : Delphix API to update an environment user
# Author       : Alan Bitterman
# Created      : 2021-01-23
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage:
#  ./env_user_update.sh [environment] [username] [password]
#  
# Interactive Usage:
#  ./env_user_update.sh
#
# Command Line Usage:
#  ./env_user_update.sh linux1 postgres delphix
#
#
#########################################################
## Parameter Initialization ...

###. ./delphix_engine.conf
#
# Delphix Engine Configuration Parameters ...
# 
#DMIP="13.90.196.157"
DMIP="172.16.129.132"
BaseURL="http://${DMIP}/resources/json/delphix"
#DMUSER=delphix_admin
#DMPASS=delphix
DMUSER=admin
DMPASS=Admin-12
COOKIE="~/cookies.txt"            # or use /tmp/cookies.txt 
COOKIE=`eval echo $COOKIE`
CONTENT_TYPE="Content-Type: application/json"
DELAYTIMESEC=10
DT=`date '+%Y%m%d%H%M%S'`

#
# Change API Version for your respective Delphix Platform in 
# . ./jqJSON_subroutines.sh
# OR the respective line later in the code if the subroutines are local
#

#
# Leave these values empty for Interactive Usage
# or use the parametes on the command line ...
#
DEF_TARGET_ENV=""   	# Hard Coded Default Environment ...
DEF_TARGET_USER=""	# Hard Coded User ...
DEF_PWD=""		# Hard Coded Password ...

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

#. ./jqJSON_subroutines.sh

jqParse() {
   STR=$1                  # json string
   FND=$2                  # name to find
   RESULTS=""              # returned name value
   RESULTS=`echo $STR | jq --raw-output '.'"$FND"''`
   #echo "Results: ${RESULTS}"
   if [[ "${FND}" == "status" ]] && [[ "${RESULTS}" != "OK" ]]
   then
      echo "Error: Invalid Status, please check code ... ${STR}"
      exit 1;
   elif [[ "${RESULTS}" == "" ]]
   then 
      echo "Error: No Results ${FND}, please check code ... ${STR}"
      exit 1;
   fi   
   echo "${RESULTS}"
}  


#
# Session and Login ...
#
RestSession() {
   DMUSER=$1               # Username
   DMPASS=$2               # Password
   BaseURL=$3              #
   COOKIE=$4               #
   CONTENT_TYPE=$5         #

   STATUS=`curl -s -X POST -k --data @- $BaseURL/session -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "APISession",
    "version": {
        "type": "APIVersion",
        "major": 1,
        "minor": 10,
        "micro": 0
    }
}
EOF
`

   #echo "Session: ${STATUS}"
   RESULTS=$( jqParse "${STATUS}" "status" )

   STATUS=`curl -s -X POST -k --data @- $BaseURL/login -b "${COOKIE}" -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "LoginRequest",
    "username": "${DMUSER}",
    "password": "${DMPASS}"
}
EOF
`

   #echo "Login: ${STATUS}"
   RESULTS=$( jqParse "${STATUS}" "status" )

   echo $RESULTS
}

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [[ "${RESULTS}" != "OK" ]]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get Environment reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_ENV="${1}"
if [[ "${TARGET_ENV}" == "" ]]
then
   ZTMP="Environment"
   if [[ "${DEF_TARGET_ENV}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select (.type=="UnixHostEnvironment" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_ENV
      if [[ "${TARGET_ENV}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_ENV=${DEF_TARGET_ENV}
   fi
fi

#
# Parse out reference for name of $TARGET_ENV ...
#
ENV_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'" and .namespace==null) | .reference '`
echo "env reference: ${ENV_REFERENCE}"

#
# Parse out primaryUser ...
#
HOST_USER=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'") | .primaryUser '`
echo "primaryUser reference: ${HOST_USER}"

#########################################################
## Get Users reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/environment/user -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_USER="${2}"
if [[ "${TARGET_USER}" == "" ]]
then
   ZTMP="Environment User"
   if [[ "${DEF_TARGET_USER}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_USER
      if [[ "${TARGET_USER}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_USER=${DEF_TARGET_USER}
   fi
fi

#
# Parse out reference for name of $ENV_REFERENCE ...
#
USER_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .name=="'"${TARGET_USER}"'" and .namespace==null) | .reference '`
echo "user reference: ${USER_REFERENCE}"
if [[ "${USER_REFERENCE}" == "" ]]
then
   echo "Error: No user reference found for ${TARGET_ENV} and ${TARGET_USER}, please verify values. Exiting ..."
   exit 1;
fi

#########################################################
## Password from Command Line Parameters ...

PWD="${3}"
ZTMP="New Password"
if [[ "${PWD}" == "" ]]
then
   if [[ "${DEF_PWD}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      read PWD
      if [[ "${PWD}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      PWD=${DEF_PWD}
   fi
fi
#echo "${ZTMP}: ${PWD}"

#########################################################
## environment user API ...

json="{
    \"type\": \"EnvironmentUser\",
    \"credential\":{
       \"type\": \"PasswordCredential\",
       \"password\": \"${PWD}\"
    }
}"

#echo "${json}" | jq "."
echo "json=$json" | sed 's/"password": [^[:space:]]*/"password": "******" /g'

echo "Update Environment User API "
echo "URL: curl -s -X POST -k --data @- $BaseURL/environment/user/${USER_REFERENCE}"
STATUS=`curl -s -X POST -k --data @- $BaseURL/environment/user/${USER_REFERENCE} -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`

RESULTS=$( jqParse "${STATUS}" "status" )
echo ${STATUS} | jq "."

# 
# The End is Here ...
#
echo " "
echo "Done "
exit;
