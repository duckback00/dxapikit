#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : get_jobs.sh
# Description  : Delphix API about call 
# Author       : Alan Bitterman
# Created      : 2019-01-12
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: ./get_jobs.sh
#
#########################################################
#                   DELPHIX CORP                        #
# Please make changes to the parameters below as req'd! #
#########################################################

#########################################################
## Parameter Initialization

. ./delphix_engine.conf

PAGESIZE=20
JOBSTATE="COMPLETED" #"FAILED"          # RUNNING, SUSPENDED, CANCELED, COMPLETED, FAILED
JOBTYPE="DB_ROLLBACK"
FROMDATE="2019-01-14T23:12:03.340Z"
TODATE=""
ADDEVENTS=false
SEARCHTXT="VBITT"
MAXTOTAL=2000
TARGET="ORACLE_DB_CONTAINER-5"    	#"ORACLE_VIRTUAL_SOURCE-1"       # Object reference

OBJECT="job"
DETAILS=""  				# "TRUE"

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#######################################################################
## Host Operating System Application Variables ...

#
# Set GDT Environment Variable for GNU Date if exists ...
#
which gdate 1> /dev/null 2> /dev/null
if [ $? -eq 0 ]
then
   GDT=gdate
else
   GDT=date
fi
export GDT
echo "Date Command: ${GDT}"

#
# Operating System ...
#
case "$OSTYPE" in
  solaris*) OS="SOLARIS" ;;
  darwin*) OS="MAC" ;;
  linux*) OS="LINUX" ;;
  bsd*) OS="BSD" ;;
  aix*) OS="AIX" ;;
  msys*) OS="WIN" ;;
  *) echo "unknown: $OSTYPE" ;;
esac
echo "OSTYPE: $OSTYPE ... OS: $OS"

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## API Call ...

echo " "
echo "Job API ... "

#
# These all work ...
#
#STATUS=`curl -s -X GET -k ${BaseURL}/job?pageSize=${PAGESIZE} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#STATUS=`curl -s -X GET -k ${BaseURL}/job?jobState=${JOBSTATE} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#STATUS=`curl -s -X GET -k ${BaseURL}/job?jobType=${JOBTYPE} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#STATUS=`curl -s -X GET -k ${BaseURL}/job?fromDate=${FROMDATE} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#STATUS=`curl -s -X GET -k ${BaseURL}/job?searchText=${SEARCHTXT} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#STATUS=`curl -s -X GET -k ${BaseURL}/job?target=${TARGET} -b "${COOKIE}" -H "${CONTENT_TYPE}"`

#STATUS=`curl -s -X GET -k "${BaseURL}/job?pageSize=${PAGESIZE}" -b "${COOKIE}" -H "${CONTENT_TYPE}"`
STATUS=`curl -s -X GET -k "${BaseURL}/job?pageSize=${PAGESIZE}&jobType=${JOBTYPE}" -b "${COOKIE}" -H "${CONTENT_TYPE}"`

# 
# Show Pretty (Human Readable) Output ...
#
#echo ${STATUS} | jq "."

#########################################################
# 
# Some jq parsing examples ...
#
#    {
#      "type": "Job",
#      "reference": "JOB-115",
#      "namespace": null,
#      "name": null,
#      "actionType": "DB_SYNC",
#      "target": "ORACLE_DB_CONTAINER-6",
#      "targetObjectType": "OracleDatabaseContainer",
#      "jobState": "COMPLETED",
#      "startTime": "2019-01-14T20:12:03.340Z",
#      "updateTime": "2019-01-14T20:12:25.587Z",
#      "suspendable": false,
#      "cancelable": true,
#      "queued": false,
#      "user": "USER-3",
#      "emailAddresses": null,
#      "title": "Run SnapSync for database \"VUHC\".",
#      "cancelReason": null,
#      "percentComplete": 0,
#      "targetName": "Oracle_Target/VUHC",
#      "events": null,
#      "parentActionState": "COMPLETED",
#      "parentAction": "ACTION-262"
#    },

### echo "${STATUS}" | jq ".result[].actionType"

#
# Use action or job objects ...
#
if [[ "${OBJECT}" == "action" ]]
then
   #
   # Use ACTION ...
   #
   CSV=`echo "${STATUS}" | jq --raw-output '.result[] | select (.actionType=="'"${JOBTYPE}"'" and .state=="COMPLETED") | .reference +","+ .title +","+ .details +","+ .startTime +","+ .endTime +","+ .parentAction '`
else
   # ... or ...
   #
   # Use JOB ...
   #
   CSV=`echo "${STATUS}" | jq --raw-output '.result[] | select (.actionType=="'"${JOBTYPE}"'" and .jobState=="COMPLETED") | .reference +","+ .actionType +","+ .title +","+ .startTime +","+ .updateTime +","+ .parentAction '`
fi
#echo "${CSV}"

#######################################################################
#
# Process jq CSV Results ...
#
while read info
do
if [[ "${info}" != "" ]]
then
   #
   # Parse comma seperated values (csv) line into shell variable array ...
   #
   IFS=,
   arr=($info)
   #echo "Writing Results for Table: ${arr[3]}    id: ${arr[4]}"
   #     0           1                2                                         3                           4
   # ACTION-157,DB_PROVISION,Provision VDB "DUIntegration_Dev1".,2017-09-07T20:36:40.173Z,2017-09-07T20:39:14.007Z
   #12345678901234567890
   #2017-09-14T20:00:31.566Z
   #${parameter//substring/replacement}
   #echo "Test ${arr[5]} ..."

   if [[ "${arr[3]}" != "" ]] && [[ "${arr[4]}" != "" ]]
   then
      #
      # Format Start/End Timestamps ...
      #
      str3="${arr[3]}"
      str3=${str3:0:19}
      str3=${str3//T/ }
      #
      #
      str4="${arr[4]}"
      str4=${str4:0:19}
      str4=${str4//T/ }

      #
      # Compute Timestamp Difference ...
      #
      if [[ "${OS}" == "MAC" ]]
      then
         secs=$(((`date -jf "%Y-%m-%d %H:%M:%S" "${str4}" +%s` - `date -jf "%Y-%m-%d %H:%M:%S" "${str3}" +%s`)))
      else
         secs=$((( $(${GDT} --date="${str4}" +%s) - $(${GDT} --date="${str3}" +%s) )))
      fi
      #
      # Print Results ...
      #
      printf "%-60s : %.2f minutes" ${arr[2]} $(echo "scale=2; ( $secs )/(60) " | bc)
      if [[ "${DETAILS}" != "" ]]
      then
         # $info -> arr=($info)
         #  0          1           2                                                      3                           4                 5
         # JOB-1382 DB_PROVISION Provision virtual database "Destination SQL Files". 2017-12-07T20:54:01.153Z 2017-12-07T20:54:35.616Z ACTION-12112
         tmp=" ${arr[0]} ${arr[3]:0:19} ${arr[4]:0:19} ${arr[5]}"          #`echo $info | tr -d '\n'`  # | sed -e 's/[\r\n]//g'
         printf "%s" $tmp
      fi        # end if details
      printf "\n"
   fi           # end if $info != ""
fi              # end of while do loop
done <<< "${CSV}"

# 
# The End is Hear ...
#
echo " "
echo "Done "
exit 0;
