#!/bin/bash
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2019 by Delphix. All rights reserved.
#
# Program Name : jobs_type_report.sh
# Description  : Delphix API to get Job Types and Report out 
# Author       : Alan Bitterman
# Created      : 2019-08-09
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#  3.) Include ./jqJSON_subroutines.sh
#  4.) Change values below as required
#
# Usage: ./jobs_type_report.sh
#
# Command Line Parameters:
#  ./jobs_type_report.sh [actionType] [database_name] [format]
#  ./jobs_type_report.sh DB_PROVISION VBITT [text|csv|json|raw]
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#########################################################
## Variables ...

DEFAULT_JOBTYPE="DB_REFRESH" 	# DB_PROVISION|DB_REFRESH|DB_ROLLBACK|DB_LINK
PAGEOFFSET=0
PAGESIZE=2000
FROMDT="2019-05-01T00:00:00.000Z"
TODT="2019-06-01T00:00:00.000Z"

#########################################################
#                   DELPHIX CORP                        #
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Variables ...

JOBTYPE="${1}"
if [[ "${JOBTYPE}" == "" ]]
then
   JOBTYPE="${DEFAULT_JOBTYPE}"         # DB_PROVISION|DB_REFRESH|DB_ROLLBACK|DB_LINK
fi

SOURCE_SID="${2}"

#
# Escape :
#
FROMDT=`echo "${FROMDT}" | sed s/:/%3A/g`
TODT=`echo "${TODT}" | sed s/:/%3A/g`
##echo "From ${FROMDT} TO ${TODT}"

FORMAT="${3}"
if [[ "${2}" == "csv" ]] || [[ "${2}" == "json" ]] || [[ "${2}" == "raw" ]]
then
   FORMAT="${2}"
fi
if [[ "${FORMAT}" == "" ]]
then
   FORMAT="text"
fi

#########################################################
## Authentication ...

##echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

##echo "Session and Login Successful ..."

#########################################################
## Get Users ...

USERS=`curl -s -X GET -k ${BaseURL}/user -b "${COOKIE}" -H "${CONTENT_TYPE}"`
##echo "${USERS}" | jq "."

#########################################################
## Get Database ...

if [[ "${SOURCE_SID}" != "" ]]
then
   STATUS=`curl -s -X GET -k ${BaseURL}/database -b "${COOKIE}" -H "${CONTENT_TYPE}"`
   RESULTS=$( jqParse "${STATUS}" "status" )
   #echo "${STATUS}" | jq -r "."
   #echo "Source: ${SOURCE_SID}"
   CONTAINER_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_SID}"'" and .namespace==null) | .reference '`
fi

#########################################################
## Get Job Data ...

##echo "Job API "
#STATUS=`curl -s -X GET -k ${BaseURL}/job?pageOffset=${PAGEOFFSET}'&'pageSize=${PAGESIZE}'&'fromDate=${FROMDT}'&'toDate=${TODT} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."

if [[ "${CONTAINER_REFERENCE}" != "" ]]
then
   STATUS=`curl -s -X GET -k ${BaseURL}/job?jobType=${JOBTYPE}'&'target=${CONTAINER_REFERENCE}'&'pageOffset=${PAGEOFFSET}'&'pageSize=${PAGESIZE}'&'fromDate=${FROMDT}'&'toDate=${TODT} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
else
   STATUS=`curl -s -X GET -k ${BaseURL}/job?jobType=${JOBTYPE}'&'pageOffset=${PAGEOFFSET}'&'pageSize=${PAGESIZE}'&'fromDate=${FROMDT}'&'toDate=${TODT} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
fi

if [[ "${FORMAT}" == "raw" ]]
then
   echo "${STATUS}" | jq "."
fi
#{
#      "type": "Job",
#      "reference": "JOB-346",
#      "namespace": null,
#      "name": null,
#      "actionType": "DB_REFRESH",
#      "target": "APPDATA_CONTAINER-40",
#      "targetObjectType": "AppDataContainer",
#      "jobState": "COMPLETED",
#      "startTime": "2019-05-01T21:16:08.559Z",
#      "updateTime": "2019-05-01T21:16:57.558Z",
#      "suspendable": false,
#      "cancelable": true,
#      "queued": false,
#      "user": "USER-3",
#      "emailAddresses": null,
#      "title": "Refresh database \"VAppData\".",
#      "cancelReason": null,
#      "percentComplete": 0,
#      "targetName": "AppData/VAppData",
#      "events": null,
#      "parentActionState": "COMPLETED",
#      "parentAction": "ACTION-845"
#    }

#########################################################
## Report ...

#ACTION=$JOBTYPE
#echo "${STATUS}" | jq --raw-output '.result[] | select(.actionType=="'"${ACTION}"'") '

#let i=4
#echo "${STATUS}" | jq --arg i "$i" '.result[$i | tonumber]'

if [[ "${FORMAT}" == "text" ]]
then
   printf "%-18s | %-9s | %-14s | %-24s | %-12s | %s \n" "jobType" "job" "user_name" "startTime" "jobState" "title"
   echo "-------------------+-----------+----------------+--------------------------+--------------+--------------------------"
fi 
CSV="jobType,job,user_name,startTime,jobState,title"
JSON="["
DELIM=""

ROWS=`echo ${STATUS} | jq --raw-output '.total'`
if [[ ${ROWS} -ge 1 ]]
then
   let i=0
   for (( i=0; i < ${ROWS}; ++i ))
   do
      OBJ=`echo "${STATUS}" | jq --arg i "$i" '.result[$i | tonumber]'`
      JOB=`echo "${OBJ}" | jq -r '.reference'`
      if [[ "${JOBTYPE}" == "" ]]
      then
          JOBTYPE=`echo "${OBJ}" | jq -r '.actionType'`
      fi
      USER_REF=`echo "${OBJ}" | jq -r ".user"`
      USER_NAME=`echo "${USERS}" | jq -r '.result[] | select (.reference=="'"${USER_REF}"'") | .name'`
      TITLE=`echo "${OBJ}" | jq -r ".title"`
      STARTDT=`echo "${OBJ}" | jq -r ".startTime"`
      JOBSTATE=`echo "${OBJ}" | jq -r ".jobState"`
      if [[ "${FORMAT}" == "text" ]]
      then
         printf "%-18s | %-9s | %-14s | %-24s | %-12s | %s \n" "${JOBTYPE}" "${JOB}" "${USER_NAME}" "${STARTDT}" "${JOBSTATE}" "${TITLE}"
      fi
      TITLE=`echo "${TITLE}" | sed 's/\"/\\\"/g'`

      CSV="${CSV}
\"${JOBTYPE}\",\"${JOB}\",\"${USER_NAME}\",\"${STARTDT}\",\"${JOBSTATE}\",\"${TITLE}\""

CSV="jobType,job,user_name,startTime,jobState,title"

      JSON="${JSON}
${DELIM} {
\"jobType\": \"${JOBTYPE}\",
\"job\": \"${JOB}\",
\"user_name\": \"${USER_NAME}\",
\"startTime\": \"${STARTDT}\",
\"jobState\": \"${JOBSTATE}\",
\"title\": \"${TITLE}\"
}"
      DELIM=","
   done
fi

JSON="${JSON}
]"

if [[ "${FORMAT}" == "csv" ]]
then
   echo "${CSV}"
fi
if [[ "${FORMAT}" == "json" ]]
then
   echo "${JSON}"
fi

###################################################
## The End is Hear ...

exit 0;
