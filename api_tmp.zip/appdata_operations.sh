#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2017 by Delphix. All rights reserved.
#
# Program Name : appdata_operations.sh 
# Description  : Delphix API for AppData operations
# Author       : Alan Bitterman
# Created      : 2017-12-12
# Version      : v1.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: 
# ./appdata_operations.sh [AppData_Name] [ sync | refresh | rollback | delete ]
#
#########################################################
#                   DELPHIX CORP                        #
# Please make changes to the parameters below as req'd! #
#########################################################

#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#
# Variables ... (hard coded for now) 
#
APPDATA="pgstaging"
ACTION="sync"

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Get Database ...

STATUS=`curl -s -X GET -k ${BaseURL}/database -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq "."

#########################################################
## Command Line Arguments ...

APPDATA="$1"
if [[ "${APPDATA}" == "" ]]
then
   echo "AppData Names: [copy-n-paste]"
   echo "---------------------------------"
   echo "${STATUS}" | jq --raw-output '.result[] | select (.type=="AppDataContainer") | .name ' 
   echo " "

   echo "Please Enter AppData Name (case sensitive): "
   read APPDATA
   if [ "${APPDATA}" == "" ]
   then
      echo "No AppData Name Provided, Exiting ..."
      exit 1;
   fi
fi;
echo "AppData Name: ${APPDATA}"

CONTAINER_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${APPDATA}"'" and .type=="AppDataContainer") | .reference '`
echo "container reference: ${CONTAINER_REF}"

PARENT_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.provisionContainer != null and .name=="'"${APPDATA}"'" and .type=="AppDataContainer") | .provisionContainer '`
echo "parent reference: ${PARENT_REF}"

#########################################################
## Action ...

ACTION=$2
if [[ "${ACTION}" == "" ]]
then

   echo "---------------------------------"
   echo "Options: [ sync | refresh | rollback | delete ] "
   echo "Please Enter Operation: "
   read ACTION
   if [ "${ACTION}" == "" ]
   then
      echo "No Operation Provided, Exiting ..."
      exit 1;
   fi
fi
ACTION=$(echo "${ACTION}" | tr '[:upper:]' '[:lower:]')

#########################################################
## delete ...
 
if [[ "${ACTION}" == "delete" ]]
then

   json="{
    \"type\": \"DeleteParameters\",
    \"force\": false
}
"

   echo "JSON: $json" 

   STATUS=`curl -s -X POST -k --data @- $BaseURL/database/${CONTAINER_REF}/${ACTION} -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`
   echo "${STATUS}" | jq "."

fi

#########################################################
## sync ...
 
if [[ "${ACTION}" == "sync" ]] 
then

   json="{
    \"type\": \"AppDataSyncParameters\"
}
"

   echo "JSON: $json" 

   STATUS=`curl -s -X POST -k --data @- $BaseURL/database/${CONTAINER_REF}/${ACTION} -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`
   echo "${STATUS}" | jq "."

fi

#########################################################
## refresh ...

if [[ "${ACTION}" == "refresh" ]] 
then

if [[ "${PARENT_REF}" != "" ]]
then
   json="{
    \"type\": \"RefreshParameters\",
    \"timeflowPointParameters\": {
        \"type\": \"TimeflowPointSemantic\",
        \"container\": \"${PARENT_REF}\"
    }
}
"

   echo "JSON: $json"

   STATUS=`curl -s -X POST -k --data @- $BaseURL/database/${CONTAINER_REF}/${ACTION} -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`
   echo "${STATUS}" | jq "."

else 

   echo "${ACTION} operation not available for container ${APPDATA} since it was not provisioned from anything, exiting ..."

fi    # end if parent_ref

fi    # end if refresh 

#########################################################
## rollback / rewind ...

if [[ "${ACTION}" == "rollback" ]]
then

json="{
    \"type\": \"RollbackParameters\",
    \"timeflowPointParameters\": {
        \"type\": \"TimeflowPointSemantic\",
        \"container\": \"${CONTAINER_REF}\",
        \"location\": \"LATEST_POINT\"
    }
}"

   echo "JSON: $json"

   STATUS=`curl -s -X POST -k --data @- $BaseURL/database/${CONTAINER_REF}/${ACTION} -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`
   echo "${STATUS}" | jq "."

fi



#########################################################
## The End is Here ...

echo " "
echo "Done "
exit 0;
