#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2017 by Delphix. All rights reserved.
#
# Program Name : toolkit.sh
# Description  : Delphix API toolkit call 
# Author       : Alan Bitterman
# Created      : 2017-08-12
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information
#
#  NOTE: Both referenced include files "delphix_engine.conf" and 
#        "jqJSON_subroutines.sh" code is embedded in this script
#        since this script it targeted to be ran independently.
#
# Interactive Usage: 
#  ./toolkit.sh
#  ./toolkit.sh [toolkit_name] rebuild
#  ./toolkit.sh [toolkit_name] delete
#
# Non-Interactive Usage:
#  ./toolkit.sh [toolkit_name] [show|download|hostchecker]
#
#
#########################################################
#                   DELPHIX CORP                        #
# Please make changes to the parameters below as req'd! #
#########################################################

#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf
#
# Delphix Engine Configuration Parameters ...
# 
#DMIP="172.16.160.195"             # include port if required, "172.16.160.195:80" or :443
#DMUSER=delphix_admin
#DMPASS=delphix
#COOKIE="~/cookies.txt"            # or use /tmp/cookies.txt 
#COOKIE=`eval echo $COOKIE`
#CONTENT_TYPE="Content-Type: application/json"
#DELAYTIMESEC=10
#BaseURL="http://${DMIP}/resources/json/delphix"		# http or https ...
#DT=`date '+%Y%m%d%H%M%S'`

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

#. ./jqJSON_subroutines.sh
#
# Parse ...
#
jqParse() {
   STR=$1                  # json string
   FND=$2                  # name to find
   RESULTS=""              # returned name value
   RESULTS=`echo $STR | jq --raw-output '.'"$FND"''`
   #echo "Results: ${RESULTS}"
   if [ "${FND}" == "status" ] && [ "${RESULTS}" != "OK" ]
   then
      echo "Error: Invalid Satus, please check code ... ${STR}"
      exit 1;
   elif [ "${RESULTS}" == "" ]
   then 
      echo "Error: No Results ${FND}, please check code ... ${STR}"
      exit 1;
   fi   
   echo "${RESULTS}"
}  

#
# Session and Login ...
#
RestSession() {
  DMUSER=$1               # Username
  DMPASS=$2               # Password
  BaseURL=$3              #
  COOKIE=$4               #
  CONTENT_TYPE=$5         #

   STATUS=`curl -s -X POST -k --data @- $BaseURL/session -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "APISession",
    "version": {
        "type": "APIVersion",
        "major": 1,
        "minor": 8,
        "micro": 0
    }
}
EOF
`

   #echo "Session: ${STATUS}"
   RESULTS=$( jqParse "${STATUS}" "status" )

   STATUS=`curl -s -X POST -k --data @- $BaseURL/login -b "${COOKIE}" -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "LoginRequest",
    "username": "${DMUSER}",
    "password": "${DMPASS}"
}
EOF
`

   #echo "Login: ${STATUS}"
   RESULTS=$( jqParse "${STATUS}" "status" )

   echo $RESULTS
}

#########################################################
## Get API Version Info ...

jqGet_APIVAL() {

   #echo "About API "
   STATUS=`curl -s -X GET -k ${BaseURL}/about -b "${COOKIE}" -H "${CONTENT_TYPE}"`
   #echo ${STATUS} | jq "."

   #
   # Get Delphix Engine API Version ...
   #
   major=`echo ${STATUS} | jq --raw-output ".result.apiVersion.major"`
   minor=`echo ${STATUS} | jq --raw-output ".result.apiVersion.minor"`
   micro=`echo ${STATUS} | jq --raw-output ".result.apiVersion.micro"`

   let apival=${major}${minor}${micro}
   #echo "Delphix Engine API Version: ${major}${minor}${micro}"

   if [ "$apival" == "" ]
   then
      echo "Error: Delphix Engine API Version Value Unknown $apival, exiting ..."
      exit 1;
   #else
   #   echo "Delphix Engine API Version: ${major}${minor}${micro}"
   fi
   echo $apival
}

#########################################################
## End of Subroutines ...
#########################################################

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Toolkit API Call ...

echo " "
echo "Toolkit API "
STATUS=`curl -s -X GET -k ${BaseURL}/toolkit -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo ${STATUS} | jq "."
#echo ${STATUS} | jq --raw-output ".result[] | .name +\",\"+ .prettyName"
TMP=`echo "${STATUS}" | jq --raw-output '.result[] | .name +" ["+ .prettyName + "] "'`
TMP1=`echo "${STATUS}" | jq --raw-output '.result[] | .name +"="+ .prettyName '`

#
# Get Toolkit Name ...
#
TK_NAME="${1}"
if [[ "${TK_NAME}" == "" ]]
then
   ZTMP="Toolkit Name"
   if [[ "${DEF_TK_NAME}" == "" ]]
   then

      fill=' ...................... '
      echo "-----------------------------------------------"
      #echo "name [prettyName]"
      z="name"
      printf "%s %s %s\n" "$z" "${fill:${#z}}" "[prettyName]"
      echo "-----------------------------------------------"
      #echo "${TMP1}"

IFS='='
while read line
do
   #echo "${line}"
   arr=($line)
   #echo "Name: ${arr[0]}  Value: ${arr[1]} "
   tmp0=`echo ${arr[0]} | sed 's/^[[:blank:]]*//;s/[[:blank:]]*$//'`
   tmp1=`echo ${arr[1]} | sed 's/^[[:blank:]]*//;s/[[:blank:]]*$//'`
   #NEW_PARAMS="${NEW_PARAMS}${DELIM}  \"${tmp0}\": \"${tmp1}\""
   #DELIM=","
   #fill=' ........................... '
   printf "%s %s %s\n" ${tmp0} "${fill:${#tmp0}}" ${tmp1}
done <<< "${TMP1}"
IFS=

      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TK_NAME
      if [[ "${TK_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TK_NAME=${DEF_TK_NAME}
   fi
fi

#
# Parse out container reference for name of $SOURCE_SID ...
#
TK_REF=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TK_NAME}"'") | .reference '`
echo "toolkit reference: ${TK_REF}"
if [[ "${TK_REF}" == "" ]]
then
   echo "Error: No ${ZTMP} found for ${TK_NAME} ${TK_REF}, Exiting ..."
   exit 1;
fi

#
# Select Action ...
# 
ACTION="${2}"
if [[ "${ACTION}" == "" ]]
then
   ZTMP="Valid Action"
   if [[ "${DEF_ACTION}" == "" ]]
   then
      echo "---------------------------------"
      echo "Valid Actions: delete | show | download | rebuild | hostchecker "
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read ACTION 
      if [[ "${ACTION}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      ACTION=${DEF_ACTION}
   fi
fi

#
# Delete Toolkit ...
#
if [[ "${ACTION}" == "delete" ]] && [[ "${TK_REF}" != "" ]]
then
   ANS="${3}"
   if [[ "${ANS}" != "y" ]]
   then
      echo "WARNING: any existing dSource or VDB using this toolkit will be deleted automatically"
      echo "Are you sure you want to delete? [y/N]? "
      read ANS
      if [[ "${ANS}" != "y" ]]
      then
         echo "Delete command aborted, Exiting ..."
         exit 1;
      fi
   fi

   STATUS=`curl -s -X DELETE -k ${BaseURL}/toolkit/${TK_REF} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
   echo ${STATUS} | jq "."
fi

#
# Show Toolkit ... 
#
if [[ "${ACTION}" == "show" ]] || [[ "${ACTION}" == "download" ]]  && [[ "${TK_REF}" != "" ]]
then
   STATUS=`curl -s -X GET -k ${BaseURL}/toolkit/${TK_REF} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
   if [[ "${ACTION}" == "show" ]]
   then
      echo ${STATUS} | jq ".result"
   else
      echo ${STATUS} | jq ".result" > ${TK_NAME}_${DT}.json 
      echo "Filename: ${TK_NAME}_${DT}.json created ..."
   fi
fi

#
# Rebuild Toolkit (requires additional user input) ...
#
if [[ "${ACTION}" == "rebuild" ]]  && [[ "${TK_REF}" != "" ]]
then
   STATUS=`curl -s -X GET -k ${BaseURL}/toolkit/${TK_REF} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
   echo ${STATUS} | jq ".result" > ${TK_NAME}_${DT}.json
   echo "Filename: ${TK_NAME}_${DT}.json created ..."

   echo " "
   echo "Enter New Toolkit Name [optional]: "
   read NEWNAME
   echo "Enter New Toolkit PrettyName [optional]: "
   read NEWPRETTY
   if [[ "${NEWNAME}" == "" ]] && [[ "${NEWPRETTY}" == "" ]]
   then
      echo "Are you sure you want to rebuild the existing toolkit \"${TK_NAME}\"? [y/N] " 
   else 
      echo "Are you sure you want to rebuild the toolkit with \"${NEWNAME}\" and \"${NEWPRETTY}\"? [y/N] "
   fi
   read ANS
   if [[ "${ANS}" == "y" ]]
   then
      ./toolkit_rebuild.sh "${TK_NAME}_${DT}.json" "${NEWNAME}" "${NEWPRETTY}"
   else 
      echo "Skipping rebuild ..."
   fi
fi

# 
# Hostchecker ...
#
if [[ "${ACTION}" == "hostchecker" ]]  && [[ "${TK_REF}" != "" ]]
then
   STATUS=`curl -s -X GET -k ${BaseURL}/toolkit/${TK_REF} -b "${COOKIE}" -H "${CONTENT_TYPE}"`
   #echo "${STATUS}" | jq "."
   ## jq 1.4 ## CHK=`echo "${STATUS}" | jq --raw-output ".result.resources.\"hostchecker/hostchecker.sh\""`
   ## jq 1.3 ##
   TMP=`echo "${STATUS}" | jq --raw-output ".result.resources"`
   CHK=`echo "${TMP}" | jq --raw-output '.["hostchecker/hostchecker.sh"] | select (.!=null)'`
   if [[ "${CHK}" != "" ]] 
   then
      ## jq 1.4 ## CONTENT=`echo "${STATUS}" | jq --raw-output ".result.resources.\"hostchecker/hostchecker.sh\""`
      ## jq 1.3 ##
      #CONTENT=`echo "${STATUS}" | jq --raw-output '.result.resources.["hostchecker/hostchecker.sh"]'`
      #echo "${CONTENT}" > hostchecker.sh
      echo "${CHK}" > hostchecker.sh
      chmod +x hostchecker.sh
      echo "hostchecker.sh created ..."
   else 
      echo " "
      echo "No ${TK_NAME}/resources/hostchecker/hostchecker.sh script found in toolkit ... "
   fi
fi

# 
# The End is Hear ...
#
echo " "
echo "Done "
exit 0;
