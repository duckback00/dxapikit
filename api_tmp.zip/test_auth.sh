########################################################
## Variables ...

# Replace these Variables as required ...

#DMIP="172.16.160.195"  # 5.3.1.0
DMIP="100.25.190.242"  # 5.3.0.2
DMURL="http://${DMIP}/resources/json/delphix"
DMUSER="delphix_admin"
DMPASS="delphix"
echo "Delphix Engine URL: ${DMURL}"
echo "Delphix User: ${DMUSER}" 

########################################################
## Session API ...

echo "Session API "
curl -s -X POST -k --data @- ${DMURL}/session -c "cookies.txt" -H "Content-Type: application/json" <<EOF
{
    "type": "APISession",
    "version": {
        "type": "APIVersion",
        "major": 1,
        "minor": 10,
        "micro": 0
    }
}
EOF

cat cookies.txt

########################################################
## Login API ...

echo "Login API "
curl -s -X POST -k --data @- ${DMURL}/login -b "cookies.txt" -c "cookies.txt" -H "Content-Type: application/json" <<EOF
{
  "type": "LoginRequest",
  "username": "${DMUSER}",
  "password": "${DMPASS}"
}
EOF


cat cookies.txt

########################################################
## Get some Delphix Objects ...

#echo "Environment API"
#curl -X GET -k ${DMURL}/environment -b "cookies.txt" -H "Content-Type: application/json"

echo "Database API"
curl -X GET -k ${DMURL}/database -b "cookies.txt" -H "Content-Type: application/json"

#echo "About API"
#curl -X GET -k ${DMURL}/about -b "cookies.txt" -H "Content-Type: application/json"

########################################################
## The End ...

