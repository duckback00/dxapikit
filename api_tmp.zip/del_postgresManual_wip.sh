#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2020 by Delphix. All rights reserved.
#
# Program Name : del_postgresdb.sh
# Description  : Delphix API delete postgres database 
# Author       : Alan Bitterman
# Created      : 2020-02-02
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: 
# ./del_postgresdb.sh
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## VDB Name from Command Line Parameters ...

DB_NAME="${1}"
ZTMP="Add DB Name"
if [[ "${DB_NAME}" == "" ]]
then
   if [[ "${DEF_DB_NAME}" == "" ]]
   then
      echo "---------------------------------"
      echo "Please Enter ${ZTMP} (case-sensitive): "
      read DB_NAME
      if [[ "${DB_NAME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      DB_NAME=${DEF_DB_NAME}
   fi
fi
echo "${ZTMP}: ${DB_NAME}"

#########################################################
## Get Environment ...

STATUS=`curl -sX GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "${STATUS}" | jq "."
#echo "environment: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_ENV="${2}"
if [[ "${TARGET_ENV}" == "" ]]
then
   ZTMP="Select Environment"
   if [[ "${DEF_TARGET_ENV}" == "" ]]
   then
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select (.type=="UnixHostEnvironment" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_ENV
      if [[ "${TARGET_ENV}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_ENV=${DEF_TARGET_ENV}
   fi
fi

#
# Parse out reference for name of $TARGET_ENV ...
#
ENV_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'" and .namespace==null) | .reference '`
echo "environment reference: ${ENV_REFERENCE}"

if [[ "${ENV_REFERENCE}" == "" ]]
then
   echo "Environment Reference ${ENV_REFERENCE} not found, exiting ..."
   exit 1
fi

#
# Parse out primaryUser name ...
#
HOST_USER=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${TARGET_ENV}"'" and .namespace==null) | .primaryUser '`
echo "primaryUser reference: ${HOST_USER}"

#########################################################
## Get Repository reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/repository -b "${COOKIE}" -H "${CONTENT_TYPE}"`
#echo "repository: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

TARGET_HOME="${3}"
if [[ "${TARGET_HOME}" == "" ]]
then
   ZTMP="Target Home Repository"
   if [[ "${DEF_TARGET_HOME}" == "" ]]
   then    #.type=="OracleInstall" and 
      TMP=`echo "${STATUS}" | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .namespace==null) | .name '`
      echo "---------------------------------"
      echo "${ZTMP}s: [copy-n-paste]"
      echo "${TMP}"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read TARGET_HOME
      if [[ "${TARGET_HOME}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      TARGET_HOME=${DEF_TARGET_HOME}
   fi
fi

#
# Parse out reference for name of $ENV_REFERENCE ...
#
REP_REFERENCE=`echo ${STATUS} | jq --raw-output '.result[] | select(.environment=="'"${ENV_REFERENCE}"'" and .name=="'"${TARGET_HOME}"'" and .namespace==null) | .reference '`
echo "repository reference: ${REP_REFERENCE}"
if [[ "${REP_REFERENCE}" == "" ]]
then
   echo "Error: No repository reference found for ${TARGET_ENV} and ${TARGET_HOME}, please verify values. Exiting ..."
   exit 1;
fi

#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
#echo "${STATUS}" | jq -r "."

SOURCE_CFG=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${DB_NAME}"'" and .namespace==null) | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

#########################################################
## Delete sourceconfig ...

STATUS=`curl -s -X POST -k --data @- $BaseURL/sourceconfig/${SOURCE_CFG}/delete -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{}
EOF
`

#echo ${STATUS} | jq "."
echo "Delete sourceconfig: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

############## E O F ####################################
echo " "
echo "Done ..."
echo " "
exit 0



