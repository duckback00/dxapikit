#!/bin/bash
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2020 by Delphix. All rights reserved.
#
# Program Name : masking_service_config.sh
# Description  : Delphix API to Configure Masking Service
# Author       : Alan Bitterman
# Created      : 2020-08-12
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries 
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Interactive Usage: ./masking_service_config.sh
# Command Line Usage: ./masking_service_config.sh [server] [username] [password]
# Sample: ./masking_service_config.sh 52.23.39.230 admin Admin-12
#
#########################################################
## Parameter Initialization ...

. ./delphix_engine.conf

#
# Hard Coded Defaults ...
#
#DEF_SVCHOST="52.23.39.230"
#DEF_SVCUSER="admin"
#DEF_SVCPASS="Admin-12"

# 
# ... or Force Interactive Option ...
#
DEF_SVCHOST=""
DEF_SVCUSER=""
DEF_SVCPASS=""

#########################################################
#         NO CHANGES REQUIRED BELOW THIS POINT          #
#########################################################

#########################################################
## Subroutines ...

. ./jqJSON_subroutines.sh

#########################################################
## Parameter Initialization ...

SVCHOST="${1}"
if [[ "${SVCHOST}" == "" ]]
then
   ZTMP="Enter Masking Server Hostname or IP"
   if [[ "${DEF_SVCHOST}" == "" ]]
   then
      echo "---------------------------------"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SVCHOST
      if [[ "${SVCHOST}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SVCHOST=${DEF_SVCHOST}
   fi
fi

SVCUSER="${2}"
if [[ "${SVCUSER}" == "" ]]
then
   ZTMP="Enter Masking Server Username"
   if [[ "${DEF_SVCUSER}" == "" ]]
   then
      echo "---------------------------------"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SVCUSER
      if [[ "${SVCUSER}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SVCUSER=${DEF_SVCUSER}
   fi
fi

SVCPASS="${3}"
if [[ "${SVCPASS}" == "" ]]
then
   ZTMP="Enter Masking Server Username Password"
   if [[ "${DEF_SVCPASS}" == "" ]]
   then
      echo "---------------------------------"
      echo " "
      echo "Please Enter ${ZTMP} (case sensitive): "
      read SVCPASS
      if [[ "${SVCPASS}" == "" ]]
      then
         echo "No ${ZTMP} Provided, Exiting ..."
         exit 1;
      fi
   else
      echo "No ${ZTMP} Provided, using Default ..."
      SVCPASS=${DEF_SVCPASS}
   fi
fi

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

RESULTS=$( RestSession "${DMUSER}" "${DMPASS}" "${BaseURL}" "${COOKIE}" "${CONTENT_TYPE}" )
#echo "Results: ${RESULTS}"
if [ "${RESULTS}" != "OK" ]
then
   echo "Error: Exiting ... ${RESULTS}"
   exit 1;
fi

echo "Session and Login Successful ..."

#########################################################
## Masking Service Config API Call ...

echo " "
STATUS=`curl -s -X GET -k ${BaseURL}/maskingjob/serviceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
echo ${STATUS} | jq "."

json="{
    \"type\": \"MaskingServiceConfig\",
    \"server\": \"${SVCHOST}\",
    \"credentials\": {
        \"type\": \"PasswordCredential\",
        \"password\": \"${SVCPASS}\"
    },
    \"username\": \"${SVCUSER}\"
}
"

echo "JSON: $json"

STATUS=`curl -s -X POST -k --data @- ${BaseURL}/maskingjob/serviceconfig/MASKING_SERVICE_CONFIG-1 -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${json}
EOF
`

echo ${STATUS} | jq "."

#########################################################
## Get Job Number ...

# No Job is executed for the masking serviceconfig endpoint ...

#JOB=$( jqParse "${STATUS}" "job" )
#echo "Job: ${JOB}"
#jqJobStatus "${JOB}"            # Job Status Function ...

# 
# The End is Here ...
#
echo " "
echo "Done "
exit 0;
