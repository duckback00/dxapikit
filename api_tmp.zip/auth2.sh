#!/bin/bash
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2017 by Delphix. All rights reserved.
#
# Program Name : linux_shell_authentication.sh 
# Description  : Very Basic Delphix API Example 
# Author       : Alan Bitterman
# Created      : 2017-08-09
# Version      : v1.0.0
#
# Requirements :
#  1.) curl and jq command line libraries
#  2.) Populate Delphix Engine Connection Information . ./delphix_engine.conf
#
# Usage: ./linux_shell_authentication.sh
#
#########################################################
#                   DELPHIX CORP                        #
#########################################################
 
#########################################################
## Parameter Initialization ...

#. ./delphix_engine.conf

#
# Delphix Engine Configuration Parameters ...
# 

# HTTP ...
#DMIP="172.16.160.195"
DMIP="3.135.185.65"
BaseURL="http://${DMIP}/resources/json/delphix"

# HTTPS ...
#DMIP="172.16.160.195:443"

#DMIP="52.90.137.89:443"
#BaseURL="https://${DMIP}/resources/json/delphix"

DMUSER=delphix_admin
DMPASS=delphix
#DMUSER=admin
#DMPASS=Admin-12
COOKIE="~/cookies.txt"            # or use /tmp/cookies.txt 
COOKIE=`eval echo $COOKIE`
CONTENT_TYPE="Content-Type: application/json"
DELAYTIMESEC=10
DT=`date '+%Y%m%d%H%M%S'`


. ./jqJSON_subroutines.sh

#########################################################
## Authentication ...

echo "Authenticating on ${BaseURL}"

#
# Session ...
#
echo "Session API "
STATUS=`curl -s -X POST -k --data @- ${BaseURL}/session -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "APISession",
    "version": {
        "type": "APIVersion",
        "major": 1,
        "minor": 10,
        "micro": 0
    }
}
EOF
`

echo "${STATUS}"

#
# Login ...
#
echo " "
echo "Login API ..."
#                                     NOTICE: -b "${COOKIE}" -c "${COOKIE}"   if login successful, create new cookie ..
STATUS=`curl -s -X POST -k --data @- ${BaseURL}/login -b "${COOKIE}" -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
  "type": "LoginRequest",
  "username": "${DMUSER}",
  "password": "${DMPASS}"
}
EOF
`

echo "${STATUS}"


#
# Get some object examples ...
#
echo " " 
#echo "Environment API "
#                              NOTICE: -b "${COOKIE}"    use existing valid cookie ...
#STATUS=`curl -s -X GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`

#echo "Database API "
#                              NOTICE: -b "${COOKIE}"    use existing valid cookie ...
STATUS=`curl -s -X GET -k ${BaseURL}/database -b "${COOKIE}" -H "${CONTENT_TYPE}"`
echo "${STATUS}" | jq -r "."

#SOURCE_SID="VVCl_OZS"
SOURCE_SID="delphix_demo"
#########################################################
## Get sourceconfig reference ...

STATUS=`curl -s -X GET -k ${BaseURL}/sourceconfig -b "${COOKIE}" -H "${CONTENT_TYPE}"`
RESULTS=$( jqParse "${STATUS}" "status" )
echo "${STATUS}" | jq -r "."

#
# Parse out sourceconfig reference for name of $SOURCE_SID ...
#
SOURCE_CFG=`echo "${STATUS}" | jq --raw-output '.result[] | select(.name=="'"${SOURCE_SID}"'") | .reference '`
echo "sourceconfig reference: ${SOURCE_CFG}"

#########################################################
## Get Environment primaryUser

STATUS=`curl -s -X GET -k ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}"`

#echo "Environment Status: ${STATUS}"
RESULTS=$( jqParse "${STATUS}" "status" )

#
# Parse out primaryUser for name of $SOURCE_ENV ...
#
PRIMARYUSER=`echo ${STATUS} | jq --raw-output '.result[] | select(.name=="'"${SOURCE_ENV}"'") | .primaryUser '`
echo "primaryUser reference: ${PRIMARYUSER}"



#http://${DMIP}/resources/json/delphix

#STATUS=`curl -s -X GET -k http://${DMIP}/resources/json/service/configure/smtp  -b "${COOKIE}" -H "${CONTENT_TYPE}"`

#echo "${STATUS}"
#echo "${STATUS}" | jq -r "."

echo " "
echo "Done "
exit 0;

