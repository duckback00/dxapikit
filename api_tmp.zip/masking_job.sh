#!/bin/bash
#######################################################################
# Filename: masking_job.sh
# Version: v1.0
# Date: 2020-12-14
# Last Updated: 2020-12-14 Bitt...
# Author: Alan Bitterman
#
# Description: ...
#
# Arguments:
#
#./masking_job.sh 
#   [action]			# create | update | list | delete
#      [masking_json]   	# masking parameters json file ...
#         [environmentName]     #
#            [maskingJobId]     # Required for update and delete ...
#

#
# Usage:  
# ./masking_job.sh create param.json xml_env
# 
# Sample Masking Parameters JSON File ...
#
#=== begin of file === 
#json="[
#{
#   \"jobName\": \"${MASKNAME}\",
#   \"rulesetId\": ${RSID},
#   \"multiTenant\": true,
#   \"jobDescription\": \"${ACTION} MaskingJob from API\",
#   \"feedbackSize\": 10000,
#   \"minMemory\": 1024,
#   \"maxMemory\": 1024,
#   \"onTheFlyMasking\": false,
#   \"databaseMaskingOptions\": {
#     \"batchUpdate\": true,
#     \"commitSize\": 10000,
#     \"dropConstraints\": true
#   }
#}
#]
#=== end of file ===
#
#########################################################
#                   DELPHIX CORP                        #
#########################################################
#
# Debug ...
#
#set -x 

#########################################################
## Delphix Masking Parameter Initialization

DMIP=172.16.129.132
DMUSER="admin"
DMPASS="Admin-12"
DMURL="http://${DMIP}/masking/api"
DELAYTIMESEC=10
DT=`date '+%Y%m%d%H%M%S'`

#########################################################
##        NO CHANGES REQUIED BELOW THIS LINE           ##
#########################################################

#
# Command Line Arguments ...
#
ACTION=${1}			# Action
PARAM=${2}  			# Masking Parameters JSON File 
ENV=${3}
JOBID=${4}

######################################################

echo "Action: ${ACTION}"
echo "Parameters File: ${PARAM}"
echo "Environment: ${ENV}"
echo "JobId: ${JOBID}"

if [[ ! -f ${PARAM} ]] 
then
   echo "error: missing or invalid json file"
   exit 1
fi

#########################################################
## Authentication ...

STATUS=`curl -s -X POST --header "Content-Type: application/json" --header "Accept: application/json" -d "{ \"username\": \"${DMUSER}\", \"password\": \"${DMPASS}\" }" "${DMURL}/login"`
#echo ${STATUS} | jq "."
KEY=`echo "${STATUS}" | jq --raw-output '.Authorization'`
if [[ "${KEY}" == "" ]] 
then
   echo "Invalid Token: ${STATUS}"
   echo "Exiting ..."
   exit 1;
else 
   echo "Authentication Successfull Token: ${KEY} "
fi

#######################################################################
## Get Environment ...
 
STATUS=`curl -s -X GET --header 'Accept: application/json' --header "Authorization: ${KEY}" "${DMURL}/environments"`
#echo "${STATUS}" | jq "."
ENVID=`echo "${STATUS}" | jq --raw-output ".responseList[] | select (.environmentName == \"${ENV}\") | .environmentId"`

if [[ "${ENVID}" == "" ]]
then
   echo "EnvironmentId ${ENVID} not found for Environment Name ${M_ENV}, exiting ..."
   exit 1
fi

echo "Environment Name: ${ENV}"
echo "Environment Id: ${ENVID}"

#########################################################
## Get Rule Set ...

#STATUS=`curl -s -X GET --header "Accept: application/json" --header "Authorization: ${KEY}" "${DMURL}/database-rulesets"`
#echo "${STATUS}" | jq "."
#DELRS=`echo "${STATUS}" | jq --raw-output ".responseList[] | select (.environmentId == ${ENVID}) | .databaseRulesetId"`
#echo "Rule Set Ids: ${DELRS}"

########################################################
## Create Masking Job ...

echo "---------------------------------------------------"

if [[ "${ACTION}" == "update" ]] && [[ "${JOBID}" != "" ]]
then
   echo "Updating Masking Job ${JOBID} ..."
   json="{
   \"multiTenant\": false
}"
   echo "JSON: $json"

   RESULTS=`curl -s -X PUT --header "Content-Type: application/json" --header "Accept: application/json" --header "Authorization: ${KEY}" -d "${json}" "${DMURL}/masking-jobs/${JOBID}"`
   echo "${RESULTS}" | jq "."

fi    # end if update ...

if [[ "${ACTION}" == "create" ]]
then
   echo "Creating Masking Job ..."
   json=`cat ${PARAM}`
   echo "JSON: ${json}"

   RESULTS=`curl -s -X POST --header "Content-Type: application/json" --header "Accept: application/json" --header "Authorization: ${KEY}" -d "${json}" "${DMURL}/masking-jobs"`
   echo "${RESULTS}" | jq "."

fi   # end if create ...

############## E O F ####################################
echo "Done."
exit 
