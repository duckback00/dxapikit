#!/bin/bash
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Copyright (c) 2018 by Delphix. All rights reserved.
#
# Program Name : toolkit_rebuild.sh
# Description  : Rebuild Delphix toolkit JSON file into it's components
# Author       : Alan Bitterman
# Created      : 2018-01-01
# Version      : v1.0
#
# Requirements :
#  1.) jq command line library
#
# Usage:
#                                          Optional      Optional
# ./toolkit_rebuild.sh [toolkit_filename] [new_name] [new_prettyName]
#
############################################################
#                     DELPHIX CORP                         #
#           NO CHANGES REQUIRED BELOW THIS POINT           #
############################################################

############################################################
## Functions ...

function list_include_item {
  local list="$1"
  local item="$2"
  if [[ $list =~ (^|[[:space:]])"$item"($|[[:space:]]) ]] ; then
    # yes, list include item
    result=0
  else
    result=1
  fi
  return $result
}

function size_h {
  local filename="$1"
  ## Number ## str=$(wc -c "$filename")
  ## String ##
  str=`wc -c < "${filename}"`
  echo "${str} bytes" | xargs
  #return 
}

############################################################
## Arguements ...

TKFILE="${1}"   		# "test_20171226000753.json"
BASE="${2}"			# "test"
PRETTY="${3}"			# "test vFiles"

if [[ "${TKFILE}" == "" ]] || [[ ! -e "${TKFILE}" ]]
then
   echo "ERROR: missing toolkit file or file is empty, exiting ..."
   exit 1  
fi
if [[ "${BASE}" == "" ]]
then
   BASE=`cat "${TKFILE}" | jq --raw-output ".name"`
fi
if [[ "${PRETTY}" == "" ]]
then
   PRETTY=`cat "${TKFILE}" | jq --raw-output ".prettyName"`
fi

echo "[ ... metadata ... ]"
echo "Toolkit File: ${TKFILE}"
echo "Name: ${BASE}"
echo "prettyName: ${PRETTY}"

############################################################
## Variables ...
 
MAIN="${BASE}/main.json"  	# main.json path/filename ...
JSON=""                   	# main.json content variable ...

#
# Lua Script Lists per Event ...
#
DISCOVERY_LIST="repositoryDiscovery sourceConfigDiscovery"
VIRTUAL_LIST="initialize configure reconfigure unconfigure start stop preSnapshot postSnapshot status ownershipSpec mountSpec"
DIRECT_LIST="preSnapshot postSnapshot status"
STAGED_LIST="preSnapshot postSnapshot ownershipSpec startStaging stopStaging resync status mountSpec"

############################################################
## Build main.json file ...

#
# Remove null parameters ...
#
CHK=`cat "${TKFILE}" | jq --raw-output ".virtualSourceDefinition.mountSpec"`     #echo "$CHK"
if [[ "${CHK}" == "null" ]]
then
   JSON=`cat "${TKFILE}" | jq "del(.virtualSourceDefinition.mountSpec)"`
fi

CHK=`cat "${TKFILE}" | jq --raw-output ".namespace"`     #echo "$CHK"
if [[ "${CHK}" == "null" ]]
then
   JSON=`cat "${TKFILE}" | jq "del(.namespace)"`
fi

#
# Need to validate these removales; check for if !null, how are upgradeDefinition 's handled, etc.
#
JSON=`cat "${TKFILE}" | jq "del(.reference,.upgradeDefinition)"`

#
# Get Version ...
#
VERSION=`cat "${TKFILE}" | jq --raw-output ".version"`
echo "version: ${VERSION}"

#
# Modify the Build API to single value ...
#
BUILDAPI=`cat "${TKFILE}" | jq --raw-output '.buildApi | (.major|tostring) +"."+ (.minor|tostring) +"."+ (.micro|tostring)'`
echo "buildAPI: ${BUILDAPI}"
JSON=`echo "${JSON}" | jq ".buildApi |= \"${BUILDAPI}\""`

#
# Name and PrettyName ...
#
JSON=`echo "${JSON}" | jq ".name |= \"${BASE}\""`
JSON=`echo "${JSON}" | jq ".prettyName |= \"${PRETTY}\""`

############################################################
## Resources (scripts) ...

# Note: keys may contain relative path from resources directory
# i.e. virtual/status.sh    -> path = ${BASE}/resources/virtual

echo "[ ... resources ... ]"
FILES=`cat "${TKFILE}" | jq --raw-output ".resources | keys[]"`
while read line
do
   #echo "#) ${line}"
   DIR=`dirname "${BASE}/resources/${line}"`
   if [[ ! -e ${DIR} ]]
   then
      mkdir -p ${DIR}
   fi
   CONTENT=`cat "${TKFILE}" | jq --raw-output ".resources.\"${line}\""`
   FILE=`basename "${BASE}/${line}"`
   echo "${CONTENT}" > ${DIR}/${FILE}
   SIZE_H=`size_h "${DIR}/${FILE}"`
   echo "${FILE} written to ${DIR} ${SIZE_H} ..."
done <<< "${FILES}"
JSON=`echo "${JSON}" | jq "del(.resources)"`

############################################################
## Discovery .lua Files ...

CHK=`cat "${TKFILE}" | jq --raw-output ".discoveryDefinition"`     #echo "Test ${CHK}"
if [[ "${CHK}" != "null" ]] 
then
   echo "[ ... discoveryDefinition ... ]"
   FILES=`cat "${TKFILE}" | jq --raw-output ".discoveryDefinition | keys[] "`
   while read line
   do
      if `list_include_item "${DISCOVERY_LIST}" "${line}"` ; then
         #echo "#) ${line}"
         DIR=`dirname "${BASE}/discovery/${line}"`
         if [[ ! -e ${DIR} ]]
         then
            mkdir -p ${DIR}
         fi
         CONTENT=`cat "${TKFILE}" | jq --raw-output ".discoveryDefinition.${line}"`
         FILE="${line}.lua"
         echo "${CONTENT}" > ${DIR}/${FILE}
         SIZE_H=`size_h "${DIR}/${FILE}"`
         echo "${FILE} written to ${DIR} ${SIZE_H} ..."
         JSON=`echo "${JSON}" | jq "del(.discoveryDefinition.${line})"`
      fi
   done <<< "${FILES}"
fi

############################################################
## Virtual .lua Files ...

echo "[ ... virtualSourceDefinition ... ]"
FILES=`cat "${TKFILE}" | jq --raw-output ".virtualSourceDefinition | keys[] "`
while read line
do
   if `list_include_item "${VIRTUAL_LIST}" "${line}"` ; then
      #echo "#) ${line}"
      DIR=`dirname "${BASE}/virtual/${line}"`
      if [[ ! -e ${DIR} ]]
      then
         mkdir -p ${DIR}
      fi
      CONTENT=`cat "${TKFILE}" | jq --raw-output ".virtualSourceDefinition.${line}"`
      FILE="${line}.lua"
      echo "${CONTENT}" > ${DIR}/${FILE}
      SIZE_H=`size_h "${DIR}/${FILE}"`
      echo "${FILE} written to ${DIR} ${SIZE_H} ..."
      JSON=`echo "${JSON}" | jq "del(.virtualSourceDefinition.${line})"`
   fi
done <<< "${FILES}"

############################################################
## Linked Source Direct or Staged ...

CHK=`cat "${TKFILE}" | jq --raw-output ".linkedSourceDefinition.type"`
echo "[ ... linkedSourceDefinition .type=${CHK} ... ]"

#
# Direct ...
#
if [[ "${CHK}" =~ "Direct" ]] 
then
   FILES=`cat "${TKFILE}" | jq --raw-output ".linkedSourceDefinition | keys[]"`
   while read line
   do
      if `list_include_item "${DIRECT_LIST}" "${line}"` ; then
         #echo "#) ${line}"
         DIR=`dirname "${BASE}/direct/${line}"`
         if [[ ! -e ${DIR} ]]
         then
            mkdir -p ${DIR}
         fi
         CONTENT=`cat "${TKFILE}" | jq --raw-output ".linkedSourceDefinition.${line}"`
         FILE="${line}.lua"
         echo "${CONTENT}" > ${DIR}/${FILE}
         SIZE_H=`size_h "${DIR}/${FILE}"`
         echo "${FILE} written to ${DIR} ${SIZE_H} ..."
         JSON=`echo "${JSON}" | jq "del(.linkedSourceDefinition.${line})"`
      fi
   done <<< "${FILES}"
fi

# 
# Staged ...
#
if [[ "${CHK}" =~ "Staged" ]]
then
   FILES=`cat "${TKFILE}" | jq --raw-output ".linkedSourceDefinition | keys[]"`
   while read line
   do
      if `list_include_item "${STAGED_LIST}" "${line}"` ; then
         #echo "#) ${line}"
         DIR=`dirname "${BASE}/staged/${line}"`
         if [[ ! -e ${DIR} ]]
         then
            mkdir -p ${DIR}
         fi
         CONTENT=`cat "${TKFILE}" | jq --raw-output ".linkedSourceDefinition.${line}"`
         FILE="${line}.lua"
         echo "${CONTENT}" > ${DIR}/${FILE}
         SIZE_H=`size_h "${DIR}/${FILE}"`
         echo "${FILE} written to ${DIR} ${SIZE_H} ..."
         JSON=`echo "${JSON}" | jq "del(.linkedSourceDefinition.${line})"`
      fi
   done <<< "${FILES}"
fi

############################################################
## Write main.json file ...
 
echo "${JSON}" > ${MAIN}
SIZE_H=`size_h "${MAIN}"`

echo "[ ... main.json ... ]" 
echo "${MAIN} written ${SIZE_H}, Please Review and Validate ..."

############################################################
## The End ...

exit 0
