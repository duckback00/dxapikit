
. ./delphix_engine.conf

STATUS=`curl -s -X POST -k --data @- ${BaseURL}/session -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "APISession",
    "version": {
        "type": "APIVersion",
        "major": 1,
        "minor": 10,
        "micro": 0
    }
}
EOF
`

echo "${STATUS}" | jq "."
echo " "

STATUS=`curl -s -X POST -k --data @- ${BaseURL}/login -b "${COOKIE}" -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "LoginRequest",
    "username": "${DMUSER}",
    "password": "${DMPASS}"
}
EOF
`

echo "${STATUS}" | jq "."
echo " "

CONTAINER_REFERENCE="APPDATA_CONTAINER-203"


JSON="{
  \"type\":\"AppDataProvisionParameters\",
  \"masked\":false,  
  \"container\":{
    \"sourcingPolicy\":{
	  \"logsyncEnabled\":false,
	  \"type\":\"SourcingPolicy\"
	},
	\"group\":\"GROUP-80\",
	\"name\":\"wingspan02\",
	\"type\":\"AppDataContainer\"
  },
  \"source\":{
    \"operations\":{
	  \"configureClone\":[],
	  \"preRefresh\":[],
	  \"postRefresh\":[],
	  \"preRollback\":[],
	  \"postRollback\":[],
	  \"preSnapshot\":[],
	  \"postSnapshot\":[],
	  \"preStart\":[],
	  \"postStart\":[],
	  \"preStop\":[],
	  \"postStop\":[],
	  \"type\":\"VirtualSourceOperations\"
	},
	\"parameters\":{
	  \"elkData\":\"/mnt/delphix/elk_vdb/node01\",
	  \"elkTransport\":\"9301\",
	  \"elkLogs\":\"/mnt/delphix/elk_vdb/logs\",
	  \"elkPort\":\"9201\",
	  \"elkJVM\":\"\",
	  \"elkBootstrap\":true,
	  \"elkPath\":\"/mnt/provision/elasticsearch-7.5.1\",
	  \"elkRepo\":\"/mnt/delphix/elk\",
	  \"isBackup\":\"isVirtual\",
	  \"dbName\":\"wingspan02\",
	  \"nodeName\":\"node01\",
	  \"additionalNodes\":[{
	    \"environment\":\"UNIX_HOST_ENVIRONMENT-7\",
		\"environmentUser\":\"HOST_USER-7\",
		\"nodeName\":\"node02\",
		\"elkData\":\"/mnt/delphix/elk_vdb/node02\"
	  },{
	    \"environment\":\"UNIX_HOST_ENVIRONMENT-8\",
		\"environmentUser\":\"HOST_USER-8\",
		\"nodeName\":\"node03\",
		\"elkData\":\"/mnt/delphix/elk_vdb/node03\"
	  }]
	},
	\"additionalMountPoints\":[{
	    \"sharedPath\":\"/\",
		\"mountPath\":\"/mnt/delphix/elk_vdb\",
		\"environment\":\"UNIX_HOST_ENVIRONMENT-7\",
		\"type\":\"AppDataAdditionalMountPoint\" 
        },{
	    \"sharedPath\":\"/\",
		\"mountPath\":\"/mnt/delphix/elk_vdb\",
		\"environment\":\"UNIX_HOST_ENVIRONMENT-8\",
		\"type\":\"AppDataAdditionalMountPoint\"
	}],
    \"allowAutoVDBRestartOnHostReboot\":true,
	\"logCollectionEnabled\":false,
	\"name\":\"wingspan02\",
	\"type\":\"AppDataVirtualSource\"
  },
  \"sourceConfig\":{
	  \"path\":\"/mnt/delphix/elk_vdb\",
	  \"name\":\"wingspan02\",
	  \"repository\":\"APPDATA_REPOSITORY-19\",
	  \"linkingEnabled\":true,
	  \"environmentUser\":\"HOST_USER-3\",
	  \"type\":\"AppDataDirectSourceConfig\"
  },
  \"timeflowPointParameters\": {
      \"type\": \"TimeflowPointSemantic\",
      \"container\": \"${CONTAINER_REFERENCE}\"
  }
}
"

#  \"timeflowPointParameters\":{
#          \"snapshot\":\"APPDATA_SNAPSHOT-833\",
#          \"type\":\"TimeflowPointSnapshot\"
#  }

#    \"timeflowPointParameters\": {
#        \"type\": \"TimeflowPointSemantic\",
#        \"container\": \"${CONTAINER_REFERENCE}\"
#    }


echo "JSON: ${JSON}"

STATUS=`curl -sX POST -k --data @- ${BaseURL}/database/provision -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
${JSON}
EOF
`

echo "${STATUS}" | jq "."

exit
