#!/bin/bash

ENV="172.16.129.133"  ###"Linux Host"

ACTION="${2}"
if [[ "${1}" == "appdata" ]] && [[ "${2}" != "delete" ]]
then
   #
   # AppData
   #
   ./sourceconfig_appdata_i.sh AppData "${ENV}" "Unstructured Files" /u01/delphixData/data1
   sleep 2

   ./link_appdata_i.sh AppData AppData "${ENV}"
   sleep 5

   #
   # VAppData
   #
   ./provision_appdata_i.sh AppData VAppData AppData "${ENV}" "Unstructured Files" /mnt/provision/VAppData

fi

if [[ "${1}" == "oracle" ]] && [[ "${2}" != "delete" ]]
then
   #
   # orcl 
   #
   ./link_oracle_i.sh orcl Oracle_Source "${ENV}" orcl delphixdb delphixdb
   sleep 2

   #
   # VBITT
   #
   ./provision_oracle_i.sh orcl VBITT "Oracle_Target" "${ENV}" "/u01/app/oracle/product/11.2.0.4/db_1" "/mnt/provision" "200M" "true"
fi

if [[ "${2}" == "delete" ]] 
then
   if [[ "${1}" == "appdata" ]]
   then
      ./vdb_init.sh delete VAppData
      sleep 10
      ./vdb_init.sh delete AppData
      sleep 2
      ./sourceconfig_delete_i.sh AppData
   fi
   if [[ "${1}" == "oracle" ]]
   then
      ./vdb_init.sh delete VBITT
      sleep 10
      ./vdb_init.sh delete orcl
   fi
fi

