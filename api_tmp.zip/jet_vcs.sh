#!/bin/bash
# 
# Usage: 
#  ./jet_vcs.sh [ object ] [action] [name] [bookmarkname or tags]
#
# object = [ branch | bookmark | container ]
# action = [ create | list | delete | activate | restore | refresh ] 
# 

#DSOURCE="orcl"
#VDB="VBITT"
DSOURCE="AppData"
VDB="VAppData"
GROUP="AppData"
TPL="tpl"
DS="ds"
DC="dc"
NAME=""
TAGS="\"\""

if [[ "${1}" == "" ]]
then  
   echo "Error: Invalid Object, ${1} object = [branch|bookmark|container] ..."
   exit 1
fi
OBJECT="${1}"

if [[ "${2}" == "" ]]
then
   echo "Error: Invalid Action, ${2} action = [create|list|delete|activate|restore|refresh] ..."
   exit 1
fi
ACTION="${2}"

if [[ "${3}" != "" ]]
then
   NAME="${3}"
fi

if [[ "${4}" != "" ]]
then
   REFERENCE="${4}"
fi

if [[ "${5}" != "" ]]
then
   TAGS="${5}"
fi
echo "Tags: ${TAGS}"

echo "Object: ${1}"
echo "Action: ${2}"
echo "Branch or Bookmark Name: ${NAME}"

#
# Logic
#
# object action   name       reference          tags
# object action   ${3}       ${4}               ${5} 
# branch create   branchname latest             \"tag1\",\"tag2\" 
# branch create   branchname from_bookmarkname  \"tag1\",\"tag2\" 
# branch activate branchname
# branch delete   branchname
# branch list
# branch list     bookmarks
# branch list     bookmarks  tags
#
if [[ "${OBJECT}" == "branch" ]]
then
   if [[ "${ACTION}" == "create" ]]
   then
      if [[ "${REFERENCE}" == "latest" ]]
      then
         ./jetstream_branch_create_from_latest_jq.sh "${TPL}" "${DC}" "${NAME}"
      else 
         #./jetstream_branch_create_from_bookmark_jq.sh tpl dc default baseline
         ./jetstream_branch_create_from_bookmark_jq.sh "${TPL}" "${DC}" "${NAME}" "${REFERENCE}" "${TAGS}"
         TAGS="\"${TAGS}\""
      fi
      ./jetstream_bookmark_create_from_latest_jq.sh "${TPL}" "${DC}" "${NAME}" false "${TAGS}"
   elif [[ "${ACTION}" == "activate" ]] || [[ "${ACTION}" == "delete" ]] || [[ "${ACTION}" == "list" ]]
   then
      ./jetstream_branch_operations_jq.sh "${TPL}" "${DC}" "${NAME}" "${ACTION}"
   fi
#
# object   action   name         reference    tags
# object   action   ${3}         ${4}         ${5}
# bookmark create   bookmarkname [true|false] \"tag1\"
# bookmark delete   branchname   bookmarkname 
# bookmark list     branchname 
# bookmark list     tags         [value]
#
elif [[ "${OBJECT}" == "bookmark" ]]
then
   if [[ "${ACTION}" == "create" ]]
   then
      ./jetstream_bookmark_create_from_latest_jq.sh ${TPL} ${DC} "${NAME}" "${REFERENCE}" "${TAGS}"
   elif [[ "${ACTION}" == "list" ]] 
   then
      ##./jetstream_bookmark_list.sh ${TPL} ${DC}
      TMPARR=`./jetstream_bookmark_list.sh "${TPL}" "${DC}" "${NAME}" | jq -s ".[]"`
      echo "Bookmarks in ${NAME} Branch:
$TMPARR"
      #let i=0
      #while read line
      #do
      #   echo "$i) |${line}|"
      #   let i=i+1
      #done <<< "${TMPARR}"
   elif [[ "${ACTION}" == "delete" ]]
   then
      ./jetstream_bookmark_delete_jq.sh ${TPL} ${DC} "${NAME}" "${REFERENCE}" "delete"
   fi
#
# container restore [bookmarkname]
# container refresh
#
elif [[ "${OBJECT}" == "container" ]] 
then
   if [[ "${ACTION}" == "restore" ]]
   then   
      ./jetstream_container_restore_to_bookmark_jq.sh ${TPL} ${DC} "${NAME}"
   elif [[ "${ACTION}" == "refresh" ]]
   then
      ./jetstream_container_refresh_jq.sh ${TPL} ${DC}
   fi

else 
   echo "Invalid option, please use ./jet_vcs.sh [branch|bookmark|container] [create|list|delete|activate|restore|refresh] [name] [reference] [tags]"
fi

exit
