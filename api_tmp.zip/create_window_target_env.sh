
. ./delphix_engine.conf

curl -s -X POST -k --data @- ${BaseURL}/session -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "APISession",
    "version": {
        "type": "APIVersion",
        "major": 1,
        "minor": 10,
        "micro": 0
    }
}
EOF


curl -s -X POST -k --data @- ${BaseURL}/login -b "${COOKIE}" -c "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "LoginRequest",
    "username": "${DMUSER}",
    "password": "${DMPASS}"
}
EOF


curl -X POST -k --data @- ${BaseURL}/environment -b "${COOKIE}" -H "${CONTENT_TYPE}" <<EOF
{
    "type": "HostEnvironmentCreateParameters",
    "primaryUser": {
        "type": "EnvironmentUser",
        "name": ".\\\Administrator",
        "credential": {
            "type": "PasswordCredential",
            "password": "Bitterman00!"
        }
    },
    "hostEnvironment": {
        "type": "WindowsHostEnvironment",
        "name": "Windows Host"
    },
    "hostParameters": {
        "type": "WindowsHostCreateParameters",
        "host": {
            "type": "WindowsHost",
            "address": "172.16.160.134",
            "connectorPort": 9100
        }
    }
}
EOF



