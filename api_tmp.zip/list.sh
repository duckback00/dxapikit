list="XPP
MDD
FCR"

#
# Process Arrays using jq ...
#
let i=0
while read line
do
   echo "$i) |${line}|"
   let i=i+1
done <<< "${list}"

echo "=========================="

list=("element 1" "element 2" "element 3")
echo ${#list[@]}
len=${#list[@]}
for (( i=0; i<$len; i++ ))
do 
  let j=$i+1
  if [[ $j == 1 ]] 
  then
     echo "first"
  fi
  if [[ $j == $len ]]
  then
     echo "last" 
  fi
  echo "${list[$i]}" 
done

