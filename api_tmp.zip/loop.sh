#!/bin/bash

DELAYTIMESEC=300
#DELAYTIMESEC=60

while [[ "1" == "1" ]]
do
   ./vdb_operations.sh sync AppData
   echo "Snapshot: " $(date) "Completed"
   sleep ${DELAYTIMESEC}
done

