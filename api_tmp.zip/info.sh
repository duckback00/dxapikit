#!/bin/bash
#
# Copyright (c) 2017 by Delphix. All rights reserved.
#
# Program Name : info.sh
# Description  : Parse through the phonehome json-bundle file to
#              : get execution times for the provided ACTION ...
# Author       : Alan Bitterman
# Created      : 2017-10-03
# Version      : v1.6
# 
# Ver | Who | Date       | Change 
#-----+-----+------------+----------------------------------------
# 1.6 | AMB | 2017-12-28 | Updated Details Output 
#     |     |            |
#-----+-----+------------+----------------------------------------
#
# Requirements :
#  1.) jq command line library
#  2.) The phonehome json-bundle file must exist in this directory
#      or full path must be specified
#
# Usage:
#  ./info.sh [ACTION] [json_file] [job|action] [details]
#  ./info.sh 		 	# Defaults are DB_PROVISION json-bundle job
#  ./info.sh DB_PROVISION 
#  ./info.sh DB_REFRESH
#  ./info.sh DB_ROLLBACK
#  ./info.sh DB_RESET
#  ./info.sh DB_SYNC
#  ./info.sh DB_DELETE
#  ./info.sh DB_LINK            # first SYNC job is initial ingestion
#
#  ./info.sh [ACTION] [json_file] [job|action] [details]
#  ./info.sh DB_PROVISION json.json job details
#  ./info.sh DB_PROVISION json.json action details
# 
# -------------------------------------------------------------
#
# To get the phonehome json file from the Support Bundle ...
#
# Go into the phonehome directory and copy the file json-bundle to this script location ...
#
# -------------------------------------------------------------
#
# Tip to get the latest phonehome JSON data file !!!
#
# Replace your authorization username:password ...
# Replace the Engine UUID with the customer specific one ...
# Replace the redirect output filename, phonehome.json, as required ...
#
#curl -s -X GET --header "Accept: application/json" -u "alan.bitterman@delphix.com:******" "https://phonehome.delphix.com/api/v1/engine/4207e297-c7c2-2567-4e74-a22b07ec98d4/json" > phonehome.json
#

#######################################################################
#
# DEBUG ...
#
#set -x
echo "Script to parse phonehome json file for either action or job object data - v1.6"

#######################################################################
## Command Line Arguements ...

#
# Action to harvest ...
#
ACTION="DB_PROVISION"
if [[ "${1}" != "" ]]
then
   ACTION="${1}"
else 
   echo "No ACTION ${ACTION} provided, using \"DB_PROVISION\""
fi
if [[ "${ACTION:0:2}" != "DB" ]]
then
   echo "Warning: Action ${ACTION} should begin with DB_, such as DB_PROVISION"
fi

# 
# JSON source file ...
#
JSON="json-bundle"
if [[ "${2}" != "" ]]
then
   JSON="${2}"
else
   echo "No JSON ${JSON} filename provided, using \"json-bundle\""
fi
if [[ ! -f "${JSON}" ]]
then
   echo "File ${JSON} not found, exiting ..."
   exit 1;
fi

#
# JSON Source Object ...
#
OBJECT="job"                    # Use action or job only!
if [[ "${3}" != "" ]]
then
   OBJECT="${3}"
fi

#
# Details ...
# 
DETAILS=""
if [[ "${4}" != "" ]]
then 
   DETAILS="${4}"
fi

#######################################################################
## jq command against phonehome json-bundle ...
 
# 
# Use action or job objects ...
#
if [[ "${OBJECT}" == "action" ]]
then
   # 
   # Use ACTION ...
   #
   STATUS=`cat ${JSON} | jq --raw-output '.domain.action.result[] | select (.actionType=="'"${ACTION}"'" and .state=="COMPLETED") | .reference +","+ .title +","+ .details +","+ .startTime +","+ .endTime +","+ .parentAction '`
else 
   # ... or ...
   #
   # Use JOB ...
   #
   STATUS=`cat ${JSON} | jq --raw-output '.domain.job.result[] | select (.actionType=="'"${ACTION}"'" and .jobState=="COMPLETED") | .reference +","+ .actionType +","+ .title +","+ .startTime +","+ .updateTime +","+ .parentAction '`
fi
echo "${STATUS}"

#######################################################################
## Host Operating System Application Variables ...

#
# Set GDT Environment Variable for GNU Date if exists ...
#
which gdate 1> /dev/null 2> /dev/null
if [ $? -eq 0 ]
then
   GDT=gdate
else
   GDT=date
fi
export GDT
echo "Date Command: ${GDT}"

#
# Operating System ...
#
case "$OSTYPE" in
  solaris*) OS="SOLARIS" ;;
  darwin*) OS="MAC" ;; 
  linux*) OS="LINUX" ;;
  bsd*) OS="BSD" ;;
  aix*) OS="AIX" ;;
  msys*) OS="WIN" ;;
  *) echo "unknown: $OSTYPE" ;;
esac
echo "OSTYPE: $OSTYPE ... OS: $OS"

#######################################################################
#
# Process jq STATUS Results ... 
#
while read info
do
if [[ "${info}" != "" ]]
then
   #
   # Parse comma seperated values (csv) line into shell variable array ...
   #
   IFS=,
   arr=($info)
   echo "Writing Results for Table: ${arr[3]}    id: ${arr[4]}"
   #     0           1                2                                         3                           4
   # ACTION-157,DB_PROVISION,Provision VDB "DUIntegration_Dev1".,2017-09-07T20:36:40.173Z,2017-09-07T20:39:14.007Z
   #12345678901234567890
   #2017-09-14T20:00:31.566Z
   #${parameter//substring/replacement}
   #echo "Test ${arr[5]} ..."

   if [[ "${arr[3]}" != "" ]] && [[ "${arr[4]}" != "" ]]
   then
      #
      # Format Start/End Timestamps ...
      #
      str3="${arr[3]}"
      str3=${str3:0:19} 
      str3=${str3//T/ }
      #
      str4="${arr[4]}"
      str4=${str4:0:19}
      str4=${str4//T/ }

      #
      # Compute Timestamp Difference ...
      #
      if [[ "${OS}" == "MAC" ]] 
      then
         secs=$(((`date -jf "%Y-%m-%d %H:%M:%S" "${str4}" +%s` - `date -jf "%Y-%m-%d %H:%M:%S" "${str3}" +%s`)))
      else
         secs=$((( $(${GDT} --date="${str4}" +%s) - $(${GDT} --date="${str3}" +%s) )))
      fi
      #
      # Print Results ...
      #
      printf "%-60s : %.2f minutes" ${arr[2]} $(echo "scale=2; ( $secs )/(60) " | bc)
      if [[ "${DETAILS}" != "" ]]
      then
         # $info -> arr=($info)
         #  0          1           2                                                      3                           4                 5 
         # JOB-1382 DB_PROVISION Provision virtual database "Destination SQL Files". 2017-12-07T20:54:01.153Z 2017-12-07T20:54:35.616Z ACTION-12112
         tmp=" ${arr[0]} ${arr[3]:0:19} ${arr[4]:0:19} ${arr[5]}"          #`echo $info | tr -d '\n'`  # | sed -e 's/[\r\n]//g'
         printf "%s" $tmp
      fi        # end if details 
      printf "\n"
   fi    	# end if $info != ""
fi              # end of while do loop
done <<< "${STATUS}"
IFS= 

#######################################################################
## Done ...

echo "Done ..."
exit 0;

