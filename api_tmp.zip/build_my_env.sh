
#
# Create Groups in DE ...
#
./group_operations.sh create "AppData"
./group_operations.sh create "Postgres"
./group_operations.sh create "MySQL"
./group_operations.sh create "Mongo"
sleep 1

./group_operations.sh create "Oracle_Source"
./group_operations.sh create "Oracle_Target"
sleep 1

./group_operations.sh create "Windows_Source"
./group_operations.sh create "Windows_Target"

./group_operations.sh delete Untitled

sleep 1
# 
# Add Oracle Template ...
#
./vdb_oracle_template.sh 200M

#
# Verify Oracle Environment is Up and listener/database are running ...
#
./create_oracle_target_env.sh

#
# Verify Windows Environment is Up and SQL Server is running ...
#
#./create_window_target_env.sh
#. .\create_window_target_env.ps1

